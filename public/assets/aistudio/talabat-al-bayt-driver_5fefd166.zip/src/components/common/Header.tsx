import React from 'react';
import { RefreshCw, Database, ArrowRight, ShieldCheck, UserCheck, Power } from 'lucide-react';
import { DriverProfile } from '../../types';

interface HeaderProps {
  title?: string;
  driver: DriverProfile;
  showBack?: boolean;
  onBack?: () => void;
  onToggleAvailability: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  onOpenSupabaseConfig: () => void;
  isSupabaseLive: boolean;
  lastSyncTime?: Date;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  driver,
  showBack = false,
  onBack,
  onToggleAvailability,
  onRefresh,
  isRefreshing,
  onOpenSupabaseConfig,
  isSupabaseLive,
}) => {
  const isOnline = driver.availability === 'online';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-xs transition-colors">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Left Section: Back button or Driver Wordmark */}
        {showBack ? (
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={onBack}
              className="w-10 h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 transition-all text-slate-700 flex items-center justify-center shrink-0"
              title="العودة"
              aria-label="العودة"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <span className="text-[11px] font-medium text-slate-500 block leading-tight">تفاصيل</span>
              <h1 className="text-base font-bold text-slate-900 truncate">
                {title || 'تفاصيل الطلب'}
              </h1>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-bold text-sm flex items-center justify-center shrink-0 shadow-xs overflow-hidden ring-2 ring-emerald-500/20">
              {driver.avatarUrl ? (
                <img
                  src={driver.avatarUrl}
                  alt={driver.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                driver.name.charAt(0) || 'ك'
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-slate-900 truncate leading-none">
                  {driver.name}
                </span>
                {driver.status === 'approved' && (
                  <span title="كابتن معتمد">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-1">
                <span>{driver.governorate || 'المنصورة'}</span>
                <span>·</span>
                <span className="truncate">{driver.vehicleModel || 'مركبة التوصيل'}</span>
              </div>
            </div>
          </div>
        )}

        {/* Right Section: DB Indicator, Refresh, Availability Toggle */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Supabase Status Button */}
          <button
            onClick={onOpenSupabaseConfig}
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
              isSupabaseLive
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
            }`}
            title="حالة اتصال قاعدة البيانات"
          >
            <Database className={`w-3.5 h-3.5 ${isSupabaseLive ? 'text-emerald-600' : 'text-amber-600'}`} />
            <span>{isSupabaseLive ? 'Supabase متصل' : 'وضع تجريبي'}</span>
          </button>

          {/* Refresh Action */}
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-600 hover:text-slate-900 transition-all flex items-center justify-center disabled:opacity-50"
            title="تحديث البيانات اللحظية"
            aria-label="تحديث البيانات اللحظية"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-600' : ''}`} />
          </button>

          {/* Shift Duty Toggle Button */}
          <button
            onClick={onToggleAvailability}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 ${
              isOnline
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
            }`}
            title={isOnline ? 'إيقاف استقبال الطلبات' : 'تفعيل استقبال الطلبات'}
          >
            <Power className="w-3.5 h-3.5" />
            <span>{isOnline ? 'متاح الآن' : 'غير متاح'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
