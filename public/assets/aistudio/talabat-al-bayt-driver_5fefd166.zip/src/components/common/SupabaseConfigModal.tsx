import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertTriangle, X, ShieldAlert, KeyRound, ExternalLink, RefreshCw } from 'lucide-react';
import {
  getSupabaseCredentials,
  saveSupabaseCredentials,
  clearSupabaseCredentials,
  testSupabaseConnection,
  isSupabaseConfigured,
} from '../../services/supabaseClient';

interface SupabaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigChanged: () => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({
  isOpen,
  onClose,
  onConfigChanged,
}) => {
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      const creds = getSupabaseCredentials();
      setUrl(creds.url);
      setAnonKey(creds.anonKey);
      setTestResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTest = async () => {
    if (!url.trim() || !anonKey.trim()) {
      setTestResult({
        success: false,
        message: 'يرجى إدخال كل من عنوان المشروع (Project URL) ومفتاح العميل (Anon Key).',
      });
      return;
    }

    // Save temporarily to test
    saveSupabaseCredentials(url.trim(), anonKey.trim());
    setIsTesting(true);
    setTestResult(null);

    const result = await testSupabaseConnection();
    setIsTesting(false);
    setTestResult({
      success: result.success,
      message: result.message,
    });
  };

  const handleSave = () => {
    if (url.trim() && anonKey.trim()) {
      saveSupabaseCredentials(url.trim(), anonKey.trim());
    } else {
      clearSupabaseCredentials();
    }
    onConfigChanged();
    onClose();
  };

  const handleClear = () => {
    clearSupabaseCredentials();
    setUrl('');
    setAnonKey('');
    setTestResult({
      success: true,
      message: 'تم التحويل إلى الوضع التجريبي وحذف الإعدادات المحلية.',
    });
    onConfigChanged();
  };

  const isConfigured = isSupabaseConfigured();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-emerald-700 text-white">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-emerald-200" />
            <h3 className="font-bold text-base">إعدادات الاتصال بـ Supabase</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-emerald-100 hover:text-white hover:bg-emerald-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto text-sm">
          {/* Current Mode Badge */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <span className="text-slate-600 font-medium">الوضع الحالي:</span>
            {isConfigured ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                متصل بـ Supabase
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                الوضع التجريبي (بيانات وهمية آمنة)
              </span>
            )}
          </div>

          {/* Security Notice */}
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50 text-amber-900 text-xs border border-amber-200">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold mb-0.5">ملاحظة أمان مشددة:</p>
              <p className="text-amber-800 leading-relaxed">
                استخدم فقط مفتاح العميل <strong className="font-semibold text-amber-950">anon public key</strong>. يُحظر تماماً إدخال مفتاح <span className="font-mono text-rose-700 bg-rose-50 px-1 rounded">service_role</span> حرصاً على أمان قاعدة البيانات وصلاحيات المندوبين.
              </p>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">
              عنوان المشروع (Supabase URL):
            </label>
            <input
              type="text"
              dir="ltr"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://your-project.supabase.co"
              className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none text-left"
            />
          </div>

          {/* Anon Key Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700">
              مفتاح العميل العام (Anon Public Key):
            </label>
            <div className="relative">
              <input
                type="password"
                dir="ltr"
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="w-full px-3 py-2 pl-9 text-xs font-mono rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none text-left"
              />
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* Test Status feedback */}
          {testResult && (
            <div
              className={`p-3 rounded-xl text-xs flex items-start gap-2 border ${
                testResult.success
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border-rose-200'
              }`}
            >
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <span className="font-medium leading-relaxed">{testResult.message}</span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={handleTest}
              disabled={isTesting}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-900 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'جاري فحص الاتصال...' : 'فحص الاتصال بخادم Supabase'}</span>
            </button>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleSave}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:scale-98 text-white font-bold text-xs text-center transition"
              >
                حفظ الإعدادات وتطبيقها
              </button>
              <button
                onClick={handleClear}
                className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-98 text-slate-700 font-medium text-xs transition"
              >
                الرجوع للوضع التجريبي
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
