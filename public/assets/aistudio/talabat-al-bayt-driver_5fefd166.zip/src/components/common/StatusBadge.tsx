import React from 'react';
import {
  Sparkles,
  UserCheck,
  CheckCircle2,
  PackageCheck,
  Truck,
  Check,
  X,
  ShieldCheck,
  Clock,
} from 'lucide-react';
import { OrderStatus, DriverStatus } from '../../types';

interface StatusBadgeProps {
  status: OrderStatus | DriverStatus | string;
  size?: 'sm' | 'md' | 'lg';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3.5 py-1.5 font-semibold gap-2',
  }[size];

  switch (status) {
    case 'new':
      return (
        <span className={`inline-flex items-center rounded-lg font-bold bg-amber-50 text-amber-800 border border-amber-200/80 ${sizeClasses}`}>
          <Sparkles className="w-3 h-3 text-amber-600" />
          <span>طلب جديد</span>
        </span>
      );

    case 'assigned':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/80 ${sizeClasses}`}>
          <UserCheck className="w-3 h-3 text-indigo-600" />
          <span>مسند إليك</span>
        </span>
      );

    case 'accepted':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-blue-50 text-blue-700 border border-blue-200/80 ${sizeClasses}`}>
          <CheckCircle2 className="w-3 h-3 text-blue-600" />
          <span>تم القبول</span>
        </span>
      );

    case 'picked_up':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-purple-50 text-purple-700 border border-purple-200/80 ${sizeClasses}`}>
          <PackageCheck className="w-3 h-3 text-purple-600" />
          <span>تم الاستلام</span>
        </span>
      );

    case 'in_transit':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-sky-50 text-sky-800 border border-sky-200/80 ${sizeClasses}`}>
          <Truck className="w-3 h-3 text-sky-600" />
          <span>جاري التوصيل</span>
        </span>
      );

    case 'delivered':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/80 ${sizeClasses}`}>
          <Check className="w-3 h-3 text-emerald-600" />
          <span>تم التوصيل</span>
        </span>
      );

    case 'cancelled':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-rose-50 text-rose-700 border border-rose-200/80 ${sizeClasses}`}>
          <X className="w-3 h-3 text-rose-600" />
          <span>ملغي</span>
        </span>
      );

    case 'approved':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/80 ${sizeClasses}`}>
          <ShieldCheck className="w-3 h-3 text-emerald-600" />
          <span>حساب معتمد</span>
        </span>
      );

    case 'pending':
      return (
        <span className={`inline-flex items-center rounded-lg font-semibold bg-amber-50 text-amber-800 border border-amber-200/80 ${sizeClasses}`}>
          <Clock className="w-3 h-3 text-amber-600" />
          <span>قيد المراجعة</span>
        </span>
      );

    default:
      return (
        <span className={`inline-flex items-center rounded-lg font-medium bg-slate-100 text-slate-700 ${sizeClasses}`}>
          {status}
        </span>
      );
  }
};
