import React from 'react';
import { Home, Package, Pill, Clock, User } from 'lucide-react';

export type TabType = 'home' | 'orders' | 'pharmacy' | 'history' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  regularOrdersCount?: number;
  pharmacyOrdersCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  regularOrdersCount = 0,
  pharmacyOrdersCount = 0,
}) => {
  const tabs = [
    {
      id: 'home' as TabType,
      label: 'الرئيسية',
      icon: Home,
      badge: 0,
    },
    {
      id: 'orders' as TabType,
      label: 'الطلبات',
      icon: Package,
      badge: regularOrdersCount,
      badgeColor: 'bg-emerald-600',
    },
    {
      id: 'pharmacy' as TabType,
      label: 'الصيدلية',
      icon: Pill,
      badge: pharmacyOrdersCount,
      badgeColor: 'bg-rose-600',
    },
    {
      id: 'history' as TabType,
      label: 'السجل',
      icon: Clock,
      badge: 0,
    },
    {
      id: 'profile' as TabType,
      label: 'حسابي',
      icon: User,
      badge: 0,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className={`relative flex flex-col items-center justify-center min-h-[48px] py-1 transition-all active:scale-95 ${
                isActive
                  ? 'text-emerald-700 font-bold'
                  : 'text-slate-400 hover:text-slate-600 font-medium'
              }`}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-5 h-5 transition-transform duration-150 ${
                    isActive ? 'scale-110 text-emerald-700 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
                {tab.badge > 0 && (
                  <span
                    className={`absolute -top-1.5 -left-3 min-w-[18px] h-[18px] px-1 text-[10px] font-bold text-white rounded-full flex items-center justify-center shadow-xs tabular-nums ${
                      tab.badgeColor || 'bg-emerald-600'
                    }`}
                  >
                    {tab.badge > 9 ? '9+' : tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] leading-tight tracking-tight mt-1">
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-5 h-0.5 bg-emerald-700 rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
