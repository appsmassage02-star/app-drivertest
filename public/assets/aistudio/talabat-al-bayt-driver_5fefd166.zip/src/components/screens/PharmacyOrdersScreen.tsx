import React, { useState, useMemo } from 'react';
import { Pill, Search, MapPin, Check, ArrowLeft, Snowflake, FileCheck, ShieldAlert, RefreshCw } from 'lucide-react';
import { PharmacyOrder } from '../../types';
import { StatusBadge } from '../common/StatusBadge';

interface PharmacyOrdersScreenProps {
  orders: PharmacyOrder[];
  onOpenOrder: (order: PharmacyOrder) => void;
  onAcceptOrder: (orderId: string) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const PharmacyOrdersScreen: React.FC<PharmacyOrdersScreenProps> = ({
  orders,
  onOpenOrder,
  onAcceptOrder,
  onRefresh,
  isRefreshing,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'active' | 'urgent'>('all');

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        order.orderNumber.toLowerCase().includes(q) ||
        order.store.name.toLowerCase().includes(q) ||
        order.customer.name.toLowerCase().includes(q) ||
        order.customer.area.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      if (statusFilter === 'all') return true;
      if (statusFilter === 'new') return order.status === 'new';
      if (statusFilter === 'active')
        return order.status === 'accepted' || order.status === 'picked_up' || order.status === 'in_transit';
      if (statusFilter === 'urgent') return order.urgencyLevel === 'urgent' || order.urgencyLevel === 'critical';

      return true;
    });
  }, [orders, searchQuery, statusFilter]);

  const newCount = orders.filter((o) => o.status === 'new').length;
  const activeCount = orders.filter(
    (o) => o.status === 'accepted' || o.status === 'picked_up' || o.status === 'in_transit'
  ).length;
  const urgentCount = orders.filter(
    (o) => o.urgencyLevel === 'urgent' || o.urgencyLevel === 'critical'
  ).length;

  return (
    <div className="space-y-4 pb-24 pt-4 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Title & Stats */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
            <Pill className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900 tracking-tight">طلبات الصيدلية والرعاية الطبية</h2>
            <p className="text-xs text-slate-500">أدوية، وصفات طبية، ومستلزمات صحية عاجلة</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-rose-800 bg-rose-50 border border-rose-200 px-3 py-1 rounded-xl shadow-xs tabular-nums">
            {orders.length} طلبات
          </span>
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="w-8 h-8 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 flex items-center justify-center transition disabled:opacity-50"
            title="تحديث"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-rose-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="p-3.5 rounded-2xl bg-rose-50/70 border border-rose-200/90 text-xs text-rose-950 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
        <p className="text-[11px] leading-relaxed">
          تنبيه صحي: يرجى التأكد من عبوة حفظ الأدوية المبردة ومطابقة ختم الصيدلية على الروشتة قبل التحرك للعميل.
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث برقم طلب الصيدلية، اسم الدواء، أو منطقة المريض..."
          className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-white border border-slate-200/90 text-xs text-slate-800 placeholder-slate-400 focus:border-rose-600 focus:ring-2 focus:ring-rose-600/20 outline-none shadow-xs transition"
        />
        <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
      </div>

      {/* Segmented Filter Control */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setStatusFilter('all')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'all'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          الكل ({orders.length})
        </button>
        <button
          onClick={() => setStatusFilter('urgent')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'urgent'
              ? 'bg-white text-red-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          عاجل ⚡ ({urgentCount})
        </button>
        <button
          onClick={() => setStatusFilter('new')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'new'
              ? 'bg-white text-amber-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          جديدة ({newCount})
        </button>
        <button
          onClick={() => setStatusFilter('active')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'active'
              ? 'bg-white text-blue-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          جارية ({activeCount})
        </button>
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="py-14 px-4 text-center bg-white rounded-2xl border border-slate-200/80 space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-400 flex items-center justify-center mx-auto">
            <Pill className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">لا توجد طلبات صيدلية مطابقة</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              جرب تغيير خيارات التصفية أو البحث لعرض طلبات الصيدليات الأخرى.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-3.5">
          {filteredOrders.map((order) => {
            const isNew = order.status === 'new';

            return (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-white border border-rose-200/90 shadow-xs hover:border-rose-300 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
                        <Pill className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-bold text-sm text-slate-900 leading-tight">
                            {order.store.name}
                          </h3>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                            صيدلية
                          </span>
                        </div>
                        <span className="text-[11px] font-mono font-medium text-slate-400">
                          #{order.orderNumber}
                        </span>
                      </div>
                    </div>
                    <StatusBadge status={order.status} size="sm" />
                  </div>

                  {/* Route */}
                  <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50/80 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-rose-600 shrink-0" />
                      <span className="text-slate-400">الصيدلية:</span>
                      <span className="font-semibold text-slate-800 truncate">{order.store.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                      <span className="text-slate-400">المريض:</span>
                      <span className="font-semibold text-slate-800 truncate">{order.customer.address}</span>
                    </div>
                  </div>

                  {/* Medical specifics */}
                  {order.hasColdStorageMedicines && (
                    <div className="flex items-center gap-1.5 text-xs text-sky-800 bg-sky-50 px-2.5 py-1.5 rounded-lg border border-sky-200">
                      <Snowflake className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                      <span className="font-medium">أدوية تتطلب حفظ مبرد (حافظة ثلج)</span>
                    </div>
                  )}

                  {/* Metadata */}
                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-2">
                      <span>{order.itemsCount} أدوية</span>
                      <span>·</span>
                      <span>{order.distanceKm} كم</span>
                      <span>·</span>
                      <span className={order.isPaid ? 'text-emerald-700 font-semibold' : 'text-amber-800 font-semibold'}>
                        {order.isPaid ? 'مدفوع إلكترونياً' : 'تحصيل كاش'}
                      </span>
                    </div>
                    <div className="text-sm font-black text-rose-700 font-mono">
                      +{order.driverFee.toFixed(2)} ر.س
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 border-t border-slate-100">
                  {isNew ? (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onAcceptOrder(order.id)}
                        className="h-10 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                      >
                        <Check className="w-4 h-4" />
                        <span>قبول طلب الصيدلية</span>
                      </button>
                      <button
                        onClick={() => onOpenOrder(order)}
                        className="h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-[0.98] text-slate-700 font-bold text-xs transition"
                      >
                        معاينة الوصفة
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => onOpenOrder(order)}
                      className="w-full h-10 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-xs"
                    >
                      <span>عرض تفاصيل الصيدلية والوصفة</span>
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
