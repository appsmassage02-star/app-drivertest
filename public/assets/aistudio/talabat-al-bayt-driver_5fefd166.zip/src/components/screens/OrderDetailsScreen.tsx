import React, { useState } from 'react';
import {
  Phone,
  MessageSquare,
  MapPin,
  CheckCircle2,
  Navigation,
  Clock,
  CreditCard,
  Banknote,
  AlertCircle,
  Store,
  User,
  ShieldCheck,
  Check,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { DeliveryOrder, OrderStatus } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { ordersService } from '../../services/ordersService';

interface OrderDetailsScreenProps {
  order: DeliveryOrder;
  onBack: () => void;
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
}

export const OrderDetailsScreen: React.FC<OrderDetailsScreenProps> = ({
  order,
  onBack,
  onUpdateStatus,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('المتجر مغلق');
  const [customReason, setCustomReason] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);

  const handleNextStatus = async () => {
    setIsProcessing(true);
    setErrorMessage(null);
    let nextStatus: OrderStatus = order.status;

    if (order.status === 'new') nextStatus = 'accepted';
    else if (order.status === 'accepted') nextStatus = 'picked_up';
    else if (order.status === 'picked_up') nextStatus = 'in_transit';
    else if (order.status === 'in_transit') nextStatus = 'delivered';

    try {
      await onUpdateStatus(order.id, nextStatus);
    } catch (err: any) {
      setErrorMessage(err?.message || 'فشل تحديث حالة الطلب');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleToggleItemPurchased = async (itemId: string, currentPurchased?: boolean) => {
    setErrorMessage(null);
    const it = order.items.find((i) => i.id === itemId);
    const nextPurchased = !currentPurchased;
    const price = it?.actual_unit_price !== undefined ? it.actual_unit_price : it?.unitPrice;
    const success = await ordersService.updateDeliveryItemPurchased(
      order.id,
      itemId,
      nextPurchased,
      price,
      it?.missing_reason
    );
    if (!success) {
      setErrorMessage('تعذر تحديث حالة الصنف في خادم Supabase.');
    }
  };

  const handleConfirmCancellation = async () => {
    setIsCancelling(true);
    setErrorMessage(null);
    const reason = cancelReason === 'أخرى' && customReason.trim() ? customReason.trim() : cancelReason;
    const success = await ordersService.cancelOrder(order.id, reason, 'regular');
    setIsCancelling(false);
    setShowCancelModal(false);
    if (success) {
      onBack();
    } else {
      setErrorMessage('فشل إرسال طلب الإلغاء إلى الخادم');
    }
  };

  const getNextActionLabel = () => {
    switch (order.status) {
      case 'new':
        return { label: 'قبول هذا الطلب', color: 'bg-emerald-700 hover:bg-emerald-800' };
      case 'accepted':
        return { label: 'بدء التسوق وتجهيز الأصناف', color: 'bg-purple-700 hover:bg-purple-800' };
      case 'picked_up':
        return { label: 'إنهاء التسوق والتوجه للعميل', color: 'bg-sky-600 hover:bg-sky-700' };
      case 'in_transit':
        return { label: 'تأكيد تسليم الطلب للعميل بنجاح ✓', color: 'bg-emerald-600 hover:bg-emerald-700' };
      case 'delivered':
        return { label: 'الطلب مكتمل ومسلّم', color: 'bg-slate-400 cursor-not-allowed' };
      case 'cancelled':
        return { label: 'الطلب ملغي', color: 'bg-slate-400 cursor-not-allowed' };
      default:
        return { label: 'تحديث الحالة', color: 'bg-slate-800' };
    }
  };

  const nextAction = getNextActionLabel();
  const isInteractiveStage = order.status === 'accepted' || order.status === 'picked_up';
  const purchasedItemsCount = order.items.filter((i) => i.isPurchased).length;

  return (
    <div className="space-y-4 pb-28 pt-4 px-4 sm:px-6 max-w-4xl mx-auto">
      {/* Cancellation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <span>طلب إلغاء الطلب</span>
            </div>
            <p className="text-xs text-slate-600">
              يرجى تحديد سبب تعذر إتمام الطلب ليتم إرساله للإدارة:
            </p>

            <div className="space-y-2">
              {['المتجر مغلق', 'العميل ألغى الطلب', 'الأصناف غير متوفرة بالكامل', 'أخرى'].map((reason) => (
                <label
                  key={reason}
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                    cancelReason === reason
                      ? 'border-rose-500 bg-rose-50 font-bold text-rose-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="cancelReason"
                    value={reason}
                    checked={cancelReason === reason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    className="accent-rose-600"
                  />
                  <span>{reason}</span>
                </label>
              ))}

              {cancelReason === 'أخرى' && (
                <input
                  type="text"
                  placeholder="اكتب سبب الإلغاء بالتفصيل..."
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500"
                />
              )}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmCancellation}
                disabled={isCancelling}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition disabled:opacity-50"
              >
                {isCancelling ? 'جاري الإلغاء...' : 'تأكيد الإلغاء'}
              </button>
              <button
                onClick={() => setShowCancelModal(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error Message Banner */}
      {errorMessage && (
        <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-[11px] font-bold text-rose-700 hover:underline px-1"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Top Card: Order Header */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400">رقم الطلب</span>
            <h2 className="text-lg font-black font-mono text-slate-900 leading-tight">
              {order.orderNumber}
            </h2>
          </div>
          <StatusBadge status={order.status} size="md" />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            {order.createdAt}
          </span>
          <span className="font-bold text-emerald-800">
            أجرة التوصيل: {order.driverFee} ر.س
          </span>
        </div>
      </div>

      {/* Store Location Card */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">نقطة الاستلام</span>
              <h3 className="font-bold text-sm text-slate-900">{order.store.name}</h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${order.store.phone}`}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
              title="اتصال بالمتجر"
            >
              <Phone className="w-4 h-4" />
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.store.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition"
              title="الاتجاهات عبر الخريطة"
            >
              <Navigation className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex items-start gap-1.5">
          <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>{order.store.address} ({order.store.area})</span>
        </div>
      </div>

      {/* Customer Location & Contact Card */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">نقطة التسليم والعميل</span>
              <h3 className="font-bold text-sm text-slate-900">{order.customer.name}</h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${order.customer.phone}`}
              className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition shadow-xs"
              title="اتصال هاتفي بالعميل"
            >
              <Phone className="w-4 h-4" />
            </a>
            <a
              href={`https://wa.me/966${order.customer.phone.replace(/^0/, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition"
              title="محادثة واتساب مع العميل"
            >
              <MessageSquare className="w-4 h-4" />
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.customer.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
              title="موقع العميل على الخريطة"
            >
              <Navigation className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="space-y-1.5 text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100">
          <div className="flex items-start gap-1.5">
            <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">{order.customer.address}</p>
              <p className="text-[11px] text-slate-500">
                {order.customer.area} • مبنى {order.customer.buildingNumber || '-'} • الدور {order.customer.floorNumber || '-'} • شقة {order.customer.apartmentNumber || '-'}
              </p>
            </div>
          </div>

          {order.customer.notes && (
            <div className="mt-2 pt-2 border-t border-slate-200/60 text-[11px] text-amber-900 bg-amber-50/80 p-2 rounded-lg">
              <span className="font-bold">ملاحظة العميل: </span>
              {order.customer.notes}
            </div>
          )}
        </div>
      </div>

      {/* Items Breakdown with Shopping Checklist */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-xs text-slate-800">
              أصناف الطلب ({order.itemsCount} صنف)
            </h3>
            {isInteractiveStage && (
              <span className="text-[10px] text-emerald-700 font-bold block mt-0.5">
                تم تجهيز: {purchasedItemsCount} من {order.items.length}
              </span>
            )}
          </div>
          <span className="text-[11px] font-bold text-slate-500">الكمية والمجموع</span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {order.items.map((item) => (
            <div key={item.id} className="py-2.5 flex items-start justify-between gap-2">
              <div className="flex items-start gap-2 flex-1">
                {isInteractiveStage && (
                  <button
                    onClick={() => handleToggleItemPurchased(item.id, item.isPurchased)}
                    className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center transition shrink-0 ${
                      item.isPurchased
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-slate-300 hover:border-emerald-500'
                    }`}
                    title="تحديد الصنف كجاهز / تم الشراء"
                  >
                    {item.isPurchased && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>
                )}
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-800 text-[11px] font-bold flex items-center justify-center shrink-0">
                      {item.quantity}×
                    </span>
                    <span className={`font-bold ${item.isPurchased ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                      {item.name}
                    </span>
                  </div>
                  {item.notes && (
                    <p className="text-[11px] text-slate-500 pr-6">ملاحظة: {item.notes}</p>
                  )}
                </div>
              </div>
              <span className="font-bold text-slate-900 shrink-0">
                {item.totalPrice.toFixed(2)} ر.س
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Financial Details */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2.5">
        <h3 className="font-bold text-xs text-slate-800 mb-1">تفاصيل الفاتورة والسداد</h3>

        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>مجموع المنتجات:</span>
          <span className="font-bold">{order.subtotal.toFixed(2)} ر.س</span>
        </div>
        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>رسوم التوصيل:</span>
          <span className="font-bold">{order.deliveryFee.toFixed(2)} ر.س</span>
        </div>
        {order.discount > 0 && (
          <div className="flex items-center justify-between text-xs text-rose-600">
            <span>الخصم:</span>
            <span className="font-bold">-{order.discount.toFixed(2)} ر.س</span>
          </div>
        )}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-sm font-black text-slate-900">
          <span>المبلغ الإجمالي المطلوب:</span>
          <span>{order.total.toFixed(2)} ر.س</span>
        </div>

        {/* Payment Method Notice */}
        <div
          className={`p-3 rounded-xl border flex items-center justify-between text-xs mt-2 ${
            order.isPaid
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {order.isPaid ? (
              <CreditCard className="w-4 h-4 text-emerald-600" />
            ) : (
              <Banknote className="w-4 h-4 text-amber-600" />
            )}
            <span className="font-bold">
              {order.isPaid ? 'الطلب مدفوع مسبقاً (لا تستلم نقد)' : 'الدفع نقدًا عند التسليم'}
            </span>
          </div>
          <span className="font-bold text-xs">
            {order.isPaid ? '0.00 ر.س نقد' : `${order.total.toFixed(2)} ر.س كاش`}
          </span>
        </div>
      </div>

      {/* Cancellation Option for Active Orders */}
      {order.status !== 'delivered' && order.status !== 'cancelled' && (
        <div className="text-center pt-1">
          <button
            onClick={() => setShowCancelModal(true)}
            className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center justify-center gap-1 mx-auto py-1 px-3 rounded-lg hover:bg-rose-50 transition"
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>طلب إلغاء الطلب لتعذر التوصيل</span>
          </button>
        </div>
      )}

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200/90 p-3 shadow-lg max-w-md mx-auto">
        <div className="flex items-center gap-2">
          {order.status !== 'delivered' && order.status !== 'cancelled' ? (
            <button
              onClick={handleNextStatus}
              disabled={isProcessing}
              className={`flex-1 py-3 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-md active:scale-98 ${nextAction.color} disabled:opacity-50`}
            >
              <Check className="w-4 h-4" />
              <span>{isProcessing ? 'جاري التحديث...' : nextAction.label}</span>
            </button>
          ) : (
            <div className="flex-1 py-3 px-4 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs text-center">
              {order.status === 'delivered' ? 'تم الانتهاء من هذا الطلب' : 'تم إلغاء هذا الطلب'}
            </div>
          )}

          <button
            onClick={onBack}
            className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
          >
            رجوع
          </button>
        </div>
      </div>
    </div>
  );
};
