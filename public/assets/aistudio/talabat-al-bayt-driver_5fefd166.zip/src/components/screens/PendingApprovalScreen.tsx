import React, { useState } from 'react';
import { Clock, ShieldCheck, CheckCircle2, FileText, Phone, MessageSquare, RefreshCw, LogOut, Sparkles } from 'lucide-react';
import { DriverProfile } from '../../types';
import { driverService } from '../../services/driverService';

interface PendingApprovalScreenProps {
  driver: DriverProfile;
  onRefresh: () => void;
  onLogout: () => void;
  onSwitchToApproved: () => void;
}

export const PendingApprovalScreen: React.FC<PendingApprovalScreenProps> = ({
  driver,
  onRefresh,
  onLogout,
  onSwitchToApproved,
}) => {
  const [isChecking, setIsChecking] = useState(false);

  const handleCheckStatus = async () => {
    setIsChecking(true);
    await driverService.getDriverProfile();
    setTimeout(() => {
      setIsChecking(false);
      onRefresh();
    }, 800);
  };

  const steps = [
    { title: 'تقديم طلب الانضمام', status: 'completed', desc: 'تم استلام البيانات الأساسية بنجاح' },
    { title: 'مطابقة وثائق الهوية والرخصة', status: 'completed', desc: 'تم التحقق من رخصة القيادة والهوية الوطنية' },
    { title: 'التدقيق الأمني والمراجعة التشغيلية', status: 'in_progress', desc: 'جاري فحص المستندات والتحقق من اشتراطات المنصة' },
    { title: 'تفعيل الحساب واستقبال الطلبات', status: 'pending', desc: 'سيصلك إشعار فوري فور إتمام الاعتماد' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between p-4 max-w-md mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between py-2 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700">
            <Clock className="w-4 h-4 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900">{driver.name}</h2>
            <span className="text-[11px] text-amber-700 font-medium">طلب الانضمام قيد الاعتماد</span>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>خروج</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="py-4 space-y-4 my-auto">
        {/* Status Hero Card */}
        <div className="bg-gradient-to-br from-amber-50 to-amber-100/60 p-5 rounded-2xl border border-amber-200 text-center space-y-2">
          <div className="w-14 h-14 rounded-full bg-amber-500 text-white flex items-center justify-center mx-auto shadow-md">
            <Clock className="w-7 h-7" />
          </div>
          <h3 className="text-base font-black text-amber-950">
            طلبك قيد المراجعة والاعتماد
          </h3>
          <p className="text-xs text-amber-800 leading-relaxed max-w-xs mx-auto">
            {driver.approvalNotes ||
              'شكراً لانضمامك إلى أسطول طلبات البيت. يقوم فريقنا الآن بمراجعة مستنداتك وسياراتك لضمان أعلى معايير الجودة.'}
          </p>
          <div className="pt-2 text-[11px] font-bold text-amber-900 bg-amber-200/50 py-1 px-3 rounded-full inline-block">
            الوقت المتوقع للاعتماد: 4 - 24 ساعة عمل
          </div>
        </div>

        {/* Steps Timeline */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-slate-700 mb-1">
            مراحل معالجة طلب الاعتماد:
          </h4>
          <div className="space-y-3">
            {steps.map((st, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="mt-0.5">
                  {st.status === 'completed' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  )}
                  {st.status === 'in_progress' && (
                    <div className="w-4 h-4 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
                  )}
                  {st.status === 'pending' && (
                    <div className="w-4 h-4 rounded-full border-2 border-slate-300" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold ${
                        st.status === 'completed'
                          ? 'text-emerald-900'
                          : st.status === 'in_progress'
                          ? 'text-amber-900'
                          : 'text-slate-400'
                      }`}
                    >
                      {st.title}
                    </span>
                    {st.status === 'in_progress' && (
                      <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md font-bold">
                        جارٍ الآن
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">{st.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Document Checklist */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>حالة المستندات المرفقة</span>
            </h4>
            <span className="text-[11px] text-slate-500 font-mono">
              {driver.vehiclePlate}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <span>الهوية الوطنية</span>
              <span className="text-emerald-600 font-bold text-[11px]">مكتمل ✓</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <span>رخصة القيادة</span>
              <span className="text-emerald-600 font-bold text-[11px]">مكتمل ✓</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <span>استمارة المركبة</span>
              <span className="text-emerald-600 font-bold text-[11px]">مكتمل ✓</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <span>الصحيفة الجنائية</span>
              <span className="text-amber-600 font-bold text-[11px]">قيد التدقيق</span>
            </div>
          </div>
        </div>

        {/* Support & Actions */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleCheckStatus}
            disabled={isChecking}
            className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
            <span>{isChecking ? 'جاري التحقق من التحديثات...' : 'تحديث حالة الاعتماد'}</span>
          </button>

          {/* Quick Demo Switch to Approved Driver */}
          <button
            onClick={onSwitchToApproved}
            className="w-full py-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-300 text-amber-900 font-bold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>معاينة الحساب المعتمد (التحويل الفوري)</span>
          </button>
        </div>
      </div>

      {/* Support footer */}
      <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs">
        <span className="text-slate-600">هل تحتاج لمساعدة فورية؟</span>
        <div className="flex items-center gap-2">
          <a
            href="https://wa.me/966500000000"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-emerald-700 font-bold hover:underline"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>واتساب</span>
          </a>
          <span className="text-slate-300">|</span>
          <a
            href="tel:920000000"
            className="flex items-center gap-1 text-slate-700 font-bold hover:underline"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>اتصال</span>
          </a>
        </div>
      </div>
    </div>
  );
};
