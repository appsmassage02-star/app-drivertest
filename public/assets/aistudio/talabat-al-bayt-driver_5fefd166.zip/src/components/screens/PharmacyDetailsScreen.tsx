import React, { useState, useRef } from 'react';
import {
  Phone,
  MessageSquare,
  MapPin,
  Pill,
  Clock,
  CreditCard,
  Banknote,
  FileText,
  Upload,
  Snowflake,
  ShieldCheck,
  Check,
  Navigation,
  Image as ImageIcon,
  AlertTriangle,
  FileCheck,
  XCircle,
  PhoneCall,
  CheckCircle2,
  Camera,
} from 'lucide-react';
import { PharmacyOrder, OrderStatus } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { ImageModal } from '../common/ImageModal';
import { ordersService } from '../../services/ordersService';
import { getSupabaseClient, isSupabaseConfigured } from '../../services/supabaseClient';

interface PharmacyDetailsScreenProps {
  order: PharmacyOrder;
  onBack: () => void;
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
}

export const PharmacyDetailsScreen: React.FC<PharmacyDetailsScreenProps> = ({
  order,
  onBack,
  onUpdateStatus,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [modalImage, setModalImage] = useState<string | null>(null);
  const [modalTitle, setModalTitle] = useState('');

  // Invoice upload state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingInvoice, setIsUploadingInvoice] = useState(false);
  const [selectedInvoiceFile, setSelectedInvoiceFile] = useState<File | null>(null);
  const [invoiceAmountInput, setInvoiceAmountInput] = useState<number>(order.subtotal || order.total);
  const [showInvoiceAmountModal, setShowInvoiceAmountModal] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<string | null>(null);

  // Cancellation modal state
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState('الدواء غير متوفر في الصيدليات المعتمدة');
  const [customReason, setCustomReason] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);

  const handleNextStatus = async () => {
    setIsProcessing(true);
    let nextStatus: OrderStatus = order.status;

    if (order.status === 'new') nextStatus = 'accepted';
    else if (order.status === 'accepted') nextStatus = 'picked_up';
    else if (order.status === 'picked_up') nextStatus = 'in_transit';
    else if (order.status === 'in_transit') nextStatus = 'delivered';

    await onUpdateStatus(order.id, nextStatus);
    setIsProcessing(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedInvoiceFile(file);
      setInvoiceAmountInput(order.subtotal || order.total);
      setShowInvoiceAmountModal(true);
    }
  };

  const handleConfirmInvoiceUpload = async () => {
    if (!selectedInvoiceFile) return;
    setIsUploadingInvoice(true);
    setShowInvoiceAmountModal(false);
    setUploadFeedback('جاري رفع الفاتورة واعتمادها في خادم الصيدلية...');

    try {
      const res = await ordersService.uploadAndAttachPharmacyInvoice(
        order.id,
        selectedInvoiceFile,
        invoiceAmountInput
      );

      if (res.success) {
        setUploadFeedback('تم اعتماد الفاتورة وتثبيت المبلغ بنجاح ✓');
      } else {
        setUploadFeedback(res.message || 'تعذر اعتماد الفاتورة في الخادم');
      }
    } catch (err: any) {
      console.error('Invoice upload failed:', err);
      setUploadFeedback('حدث خطأ أثناء رفع الفاتورة');
    } finally {
      setIsUploadingInvoice(false);
      setSelectedInvoiceFile(null);
      setTimeout(() => setUploadFeedback(null), 4000);
    }
  };

  const handleQuickDemoInvoice = async () => {
    setIsUploadingInvoice(true);
    setUploadFeedback('جاري إنشاء فاتورة تجريبية واعتمادها...');
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 250;
      canvas.height = 250;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(0, 0, 250, 250);
        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText('فاتورة صيدلية معتمدة', 30, 80);
        ctx.font = '12px sans-serif';
        ctx.fillText(`رقم الطلب: ${order.orderNumber}`, 30, 120);
        ctx.fillText(`الإجمالي: ${order.subtotal || order.total} ج.م`, 30, 150);
      }
      canvas.toBlob(async (blob) => {
        if (blob) {
          const testFile = new File([blob], `demo_receipt_${Date.now()}.png`, { type: 'image/png' });
          const res = await ordersService.uploadAndAttachPharmacyInvoice(
            order.id,
            testFile,
            order.subtotal || order.total || 50
          );
          if (res.success) {
            setUploadFeedback('تم اعتماد الفاتورة التجريبية بنجاح ✓');
          } else {
            setUploadFeedback(res.message || 'تعذر اعتماد الفاتورة');
          }
        }
        setIsUploadingInvoice(false);
        setTimeout(() => setUploadFeedback(null), 4000);
      }, 'image/png');
    } catch {
      setIsUploadingInvoice(false);
      setUploadFeedback('فشل تجهيز الفاتورة التجريبية');
      setTimeout(() => setUploadFeedback(null), 3000);
    }
  };

  const handleUpdateItemStatus = async (
    itemId: string,
    status: 'available' | 'shortage' | 'alternative' | string
  ) => {
    const item = order.items.find((i) => i.id === itemId);
    const reqQty = item?.requested_quantity || item?.quantity || 1;
    const purchasedQty = status === 'available' ? reqQty : 0;
    const shortageReason = status === 'shortage' ? 'غير متوفر بالصيدلية' : status === 'alternative' ? 'تم صرف صنف بديل' : '';
    const success = await ordersService.updatePharmacyItemStatus(
      order.id,
      itemId,
      status,
      purchasedQty,
      shortageReason,
      item?.driver_note
    );
    if (!success) {
      setUploadFeedback('تعذر تحديث حالة الصنف في خادم الصيدلية');
      setTimeout(() => setUploadFeedback(null), 3000);
    }
  };

  const handleMarkContacted = async () => {
    const success = await ordersService.markPatientContacted(order.id);
    if (!success) {
      setUploadFeedback('تعذر توثيق الاتصال في الخادم');
      setTimeout(() => setUploadFeedback(null), 3000);
    }
  };

  const handleConfirmCancellation = async () => {
    setIsCancelling(true);
    const reason = cancelReason === 'أخرى' && customReason.trim() ? customReason.trim() : cancelReason;
    const success = await ordersService.cancelOrder(order.id, reason, 'pharmacy');
    setIsCancelling(false);
    setShowCancelModal(false);
    if (success) {
      onBack();
    } else {
      setUploadFeedback('فشل إرسال طلب إلغاء الصيدلية إلى الخادم');
      setTimeout(() => setUploadFeedback(null), 3000);
    }
  };

  const getNextActionLabel = () => {
    switch (order.status) {
      case 'new':
        return { label: 'قبول طلب الصيدلية', color: 'bg-rose-700 hover:bg-rose-800' };
      case 'accepted':
        return { label: 'بدء تجهيز الروشتة في الصيدلية', color: 'bg-purple-700 hover:bg-purple-800' };
      case 'picked_up':
        return { label: 'إنهاء التجهيز وبدء التوجه للمريض', color: 'bg-sky-600 hover:bg-sky-700' };
      case 'in_transit':
        return { label: 'تأكيد تسليم الأدوية للمريض بنجاح ✓', color: 'bg-emerald-600 hover:bg-emerald-700' };
      case 'delivered':
        return { label: 'الطلب مكتمل ومسلّم', color: 'bg-slate-400 cursor-not-allowed' };
      case 'cancelled':
        return { label: 'الطلب ملغي', color: 'bg-slate-400 cursor-not-allowed' };
      default:
        return { label: 'تحديث الحالة', color: 'bg-slate-800' };
    }
  };

  const nextAction = getNextActionLabel();
  const isInteractiveStage = order.status === 'accepted' || order.status === 'picked_up';

  return (
    <div className="space-y-4 pb-28 pt-4 px-4 sm:px-6 max-w-4xl mx-auto">
      {/* Hidden file input for native camera/gallery selection */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Lightbox for prescription / invoice zoom */}
      <ImageModal
        isOpen={Boolean(modalImage)}
        imageUrl={modalImage || ''}
        title={modalTitle}
        onClose={() => setModalImage(null)}
      />

      {/* Invoice Amount Confirmation Modal */}
      {showInvoiceAmountModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
              <Camera className="w-5 h-5 shrink-0" />
              <span>تأكيد فاتورة الصيدلية</span>
            </div>
            <p className="text-xs text-slate-600">
              تم اختيار صورة الفاتورة. يرجى إدخال المبلغ الإجمالي المطبوع على فاتورة الصيدلية:
            </p>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-500 block">المبلغ الإجمالي (ر.س):</label>
              <input
                type="number"
                step="0.01"
                value={invoiceAmountInput}
                onChange={(e) => setInvoiceAmountInput(Number(e.target.value))}
                className="w-full text-sm font-bold p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-rose-600"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmInvoiceUpload}
                disabled={isUploadingInvoice || invoiceAmountInput <= 0}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition disabled:opacity-50"
              >
                اعتماد ورفع الفاتورة
              </button>
              <button
                onClick={() => {
                  setShowInvoiceAmountModal(false);
                  setSelectedInvoiceFile(null);
                }}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancellation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-2 text-rose-600 font-bold text-sm">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <span>طلب إلغاء طلب الصيدلية</span>
            </div>
            <p className="text-xs text-slate-600">
              يرجى تحديد سبب تعذر صرف أو توصيل الدواء للإدارة:
            </p>

            <div className="space-y-2">
              {[
                'الدواء غير متوفر في الصيدليات المعتمدة',
                'الوصفة الطبية غير واضحة أو منتهية',
                'المريض ألغى الطلب أو لا يرد',
                'الصيدلية مغلقة',
                'أخرى',
              ].map((reason) => (
                <label
                  key={reason}
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                    cancelReason === reason
                      ? 'border-rose-500 bg-rose-50 font-bold text-rose-900'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="phCancelReason"
                    value={reason}
                    checked={cancelReason === reason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    className="accent-rose-600"
                  />
                  <span>{reason}</span>
                </label>
              ))}

              {cancelReason === 'أخرى' && (
                <input
                  type="text"
                  placeholder="اكتب سبب الإلغاء بالتفصيل..."
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:border-rose-500"
                />
              )}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmCancellation}
                disabled={isCancelling}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition disabled:opacity-50"
              >
                {isCancelling ? 'جاري الإلغاء...' : 'تأكيد الإلغاء'}
              </button>
              <button
                onClick={() => setShowCancelModal(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Card: Pharmacy Order Header */}
      <div className="p-4 rounded-2xl bg-white border border-rose-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1 text-[11px] font-bold text-rose-600">
              <Pill className="w-3.5 h-3.5" />
              <span>طلب صيدلية معتمد</span>
            </div>
            <h2 className="text-lg font-black font-mono text-slate-900 leading-tight">
              {order.orderNumber}
            </h2>
          </div>
          <StatusBadge status={order.status} size="md" />
        </div>

        {/* Cold Storage & Prescription Alerts */}
        <div className="space-y-1.5 pt-1">
          {order.hasColdStorageMedicines && (
            <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-200 flex items-center gap-2 text-xs text-sky-900">
              <Snowflake className="w-4 h-4 text-sky-600 shrink-0" />
              <span className="font-bold">
                تنبيه: يحتوي على أدوية تبريد (إنسولين / لقاحات) - حافظ على برودة الكيس!
              </span>
            </div>
          )}

          {order.insuranceInfo && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs text-emerald-900">
              <div className="flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>تأمين طبي معتمد: {order.insuranceInfo.providerName}</span>
              </div>
              <span className="text-[10px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-emerald-300">
                {order.insuranceInfo.approvalNumber}
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            {order.createdAt}
          </span>
          <span className="font-bold text-rose-700">
            أجرة التوصيل: {order.driverFee} ر.س
          </span>
        </div>
      </div>

      {/* Prescription & Pharmacy Invoice Section */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
            <FileCheck className="w-4 h-4 text-rose-600" />
            <span>المستندات الطبية والفاتورة</span>
          </h3>
          {uploadFeedback && (
            <span className="text-[10px] font-bold text-emerald-700 animate-pulse">
              {uploadFeedback}
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Prescription Image */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-600 block">صورة الوصفة الطبية:</span>
            {order.prescriptionImages && order.prescriptionImages.length > 0 ? (
              <div
                onClick={() => {
                  setModalImage(order.prescriptionImages![0]);
                  setModalTitle('الوصفة الطبية المعتمدة');
                }}
                className="relative h-28 rounded-xl overflow-hidden border border-slate-200 cursor-pointer group shadow-xs"
              >
                <img
                  src={order.prescriptionImages[0]}
                  alt="الوصفة الطبية"
                  className="w-full h-full object-cover group-hover:scale-105 transition"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-white text-[11px] font-bold gap-1">
                  <ImageIcon className="w-4 h-4" />
                  <span>تكبير الوصفة</span>
                </div>
              </div>
            ) : (
              <div className="h-28 rounded-xl bg-slate-50 border border-slate-200 border-dashed flex flex-col items-center justify-center text-slate-400 text-xs">
                <FileText className="w-6 h-6 mb-1 opacity-50" />
                <span>بدون وصفة ورقية</span>
              </div>
            )}
          </div>

          {/* Pharmacy Invoice Image */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-slate-600 block">فاتورة الصيدلية:</span>
            {order.invoiceUrl ? (
              <div className="space-y-1">
                <div
                  onClick={() => {
                    setModalImage(order.invoiceUrl!);
                    setModalTitle('فاتورة الصيدلية الرسمية');
                  }}
                  className="relative h-24 rounded-xl overflow-hidden border border-slate-200 cursor-pointer group shadow-xs"
                >
                  <img
                    src={order.invoiceUrl}
                    alt="فاتورة الصيدلية"
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-white text-[10px] font-bold gap-1">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>معاينة</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-600 px-1 font-bold">
                  <span>المبلغ المعتمد:</span>
                  <span className="text-emerald-700">{order.invoiceAmount ? `${order.invoiceAmount.toFixed(2)} ر.س` : '-'}</span>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploadingInvoice}
                  className="w-full h-20 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 border-dashed flex flex-col items-center justify-center text-rose-700 text-xs p-2 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <Camera className={`w-5 h-5 mb-0.5 ${isUploadingInvoice ? 'animate-bounce' : ''}`} />
                  <span className="font-bold text-[11px]">
                    {isUploadingInvoice ? 'جاري الرفع...' : 'تصوير أو اختيار الفاتورة'}
                  </span>
                  <span className="text-[9px] text-rose-500">من الصيدلي</span>
                </button>
                <button
                  type="button"
                  onClick={handleQuickDemoInvoice}
                  disabled={isUploadingInvoice}
                  className="w-full text-[9px] font-bold text-slate-400 hover:text-rose-600 text-center py-0.5"
                >
                  (أو استخدام فاتورة تجريبية سريعة)
                </button>
              </div>
            )}
          </div>
        </div>

        {order.pharmacyNotes && (
          <div className="p-3 rounded-xl bg-slate-50 text-[11px] text-slate-700 border border-slate-100 leading-relaxed">
            <strong className="font-bold text-slate-900 block mb-0.5">تعليمات الصيدلي للمندوب:</strong>
            {order.pharmacyNotes}
          </div>
        )}
      </div>

      {/* Pharmacy Store Location & Stops */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase">الصيدلية المصدرة</span>
              <h3 className="font-bold text-sm text-slate-900">{order.store.name}</h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${order.store.phone}`}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
              title="اتصال بالصيدلية"
            >
              <Phone className="w-4 h-4" />
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.store.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 transition"
              title="خريطة الصيدلية"
            >
              <Navigation className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex items-start gap-1.5">
          <MapPin className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span>{order.store.address} ({order.store.area})</span>
        </div>

        {/* Multi-stops display if available */}
        {order.pharmacyStops && order.pharmacyStops.length > 1 && (
          <div className="mt-2 pt-2 border-t border-slate-100 space-y-2">
            <span className="text-[11px] font-bold text-slate-500 block">محطات الصيدليات الإضافية:</span>
            {order.pharmacyStops.map((stop, idx) => (
              <div key={stop.id} className="p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-800 font-bold text-[10px] flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <div>
                    <p className="font-bold text-slate-800">{stop.pharmacyName}</p>
                    <p className="text-[10px] text-slate-500">{stop.pharmacyAddress}</p>
                  </div>
                </div>
                {stop.pharmacyPhone && (
                  <a href={`tel:${stop.pharmacyPhone}`} className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700">
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Patient / Customer Location & Contact Documenting */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase">المريض / العميل المستلم</span>
            <h3 className="font-bold text-sm text-slate-900">{order.customer.name}</h3>
          </div>

          <div className="flex items-center gap-1.5">
            <a
              href={`tel:${order.customer.phone}`}
              className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition shadow-xs"
              title="اتصال هاتفي"
            >
              <Phone className="w-4 h-4" />
            </a>
            <a
              href={`https://wa.me/966${order.customer.phone.replace(/^0/, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition"
              title="واتساب"
            >
              <MessageSquare className="w-4 h-4" />
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.customer.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
              title="موقع العميل"
            >
              <Navigation className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="space-y-1 text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100">
          <div className="flex items-start gap-1.5">
            <MapPin className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">{order.customer.address}</p>
              <p className="text-[11px] text-slate-500">
                {order.customer.area} • مبنى {order.customer.buildingNumber || '-'} • الدور {order.customer.floorNumber || '-'}
              </p>
            </div>
          </div>
          {order.customer.notes && (
            <div className="mt-2 pt-2 border-t border-slate-200 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg font-medium">
              ملاحظة المريض: {order.customer.notes}
            </div>
          )}
        </div>

        {/* Contact Patient Documenting Button */}
        <div className="pt-1">
          {order.customerContacted ? (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>تم توثيق التواصل مع المريض بنجاح</span>
            </div>
          ) : (
            <button
              onClick={handleMarkContacted}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <PhoneCall className="w-4 h-4 text-slate-500" />
              <span>توثيق الاتصال بالمريض للتأكيد قبل التحرك</span>
            </button>
          )}
        </div>
      </div>

      {/* Medications and Items Table with Availability & Shortage Management */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-xs text-slate-800">
            قائمة الأدوية والمستلزمات ({order.items.length})
          </h3>
          <span className="text-[11px] font-bold text-slate-500">الكمية والتسعير</span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {order.items.map((item) => (
            <div key={item.id} className="py-2.5 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-md bg-rose-100 text-rose-800 text-[11px] font-bold flex items-center justify-center shrink-0">
                      {item.quantity}×
                    </span>
                    <span className="font-bold text-slate-800">{item.name}</span>
                  </div>
                  {item.unit && (
                    <p className="text-[11px] text-slate-400 pr-6">الوحدة: {item.unit}</p>
                  )}
                  {item.notes && (
                    <p className="text-[11px] text-sky-700 font-medium pr-6">{item.notes}</p>
                  )}
                </div>
                <span className="font-bold text-slate-900 shrink-0">
                  {item.totalPrice.toFixed(2)} ر.س
                </span>
              </div>

              {/* In-shopping interactive medication availability buttons */}
              {isInteractiveStage && (
                <div className="flex items-center gap-1.5 pt-1 pr-6">
                  <button
                    onClick={() => handleUpdateItemStatus(item.id, 'available')}
                    className={`py-1 px-2.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition ${
                      item.status === 'available'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                    }`}
                  >
                    <Check className="w-3 h-3" />
                    <span>متوفر</span>
                  </button>

                  <button
                    onClick={() => handleUpdateItemStatus(item.id, 'shortage')}
                    className={`py-1 px-2.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition ${
                      item.status === 'shortage'
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>غير متوفر (نقص)</span>
                  </button>

                  <button
                    onClick={() => handleUpdateItemStatus(item.id, 'alternative')}
                    className={`py-1 px-2.5 rounded-lg text-[10px] font-bold flex items-center gap-1 transition ${
                      item.status === 'alternative'
                        ? 'bg-sky-600 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                    }`}
                  >
                    <span>صُرف بديل</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Financial Breakdown */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2.5">
        <h3 className="font-bold text-xs text-slate-800 mb-1">تفاصيل الفاتورة الطبية</h3>

        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>قيمة الأدوية والمستلزمات:</span>
          <span className="font-bold">{order.subtotal.toFixed(2)} ر.س</span>
        </div>
        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>أجرة توصيل الصيدلية:</span>
          <span className="font-bold">{order.deliveryFee.toFixed(2)} ر.س</span>
        </div>
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-sm font-black text-slate-900">
          <span>المبلغ الإجمالي:</span>
          <span>{order.total.toFixed(2)} ر.س</span>
        </div>

        {/* Payment mode */}
        <div
          className={`p-3 rounded-xl border flex items-center justify-between text-xs mt-2 ${
            order.isPaid
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {order.isPaid ? (
              <CreditCard className="w-4 h-4 text-emerald-600" />
            ) : (
              <Banknote className="w-4 h-4 text-amber-600" />
            )}
            <span className="font-bold">
              {order.isPaid ? 'مدفوع بالكامل مسبقاً (أو تأمين)' : 'مطلوب تحصيل كاش من المريض'}
            </span>
          </div>
          <span className="font-bold">
            {order.isPaid ? '0.00 ر.س' : `${order.total.toFixed(2)} ر.س`}
          </span>
        </div>
      </div>

      {/* Cancellation Option for Pharmacy Orders */}
      {order.status !== 'delivered' && order.status !== 'cancelled' && (
        <div className="text-center pt-1">
          <button
            onClick={() => setShowCancelModal(true)}
            className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center justify-center gap-1 mx-auto py-1 px-3 rounded-lg hover:bg-rose-50 transition"
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>طلب إلغاء طلب الصيدلية لتعذر الصرف</span>
          </button>
        </div>
      )}

      {/* Fixed Action Button */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200/90 p-3 shadow-lg max-w-md mx-auto">
        <div className="flex items-center gap-2">
          {order.status !== 'delivered' && order.status !== 'cancelled' ? (
            <button
              onClick={handleNextStatus}
              disabled={isProcessing}
              className={`flex-1 py-3 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-md active:scale-98 ${nextAction.color} disabled:opacity-50`}
            >
              <Check className="w-4 h-4" />
              <span>{isProcessing ? 'جاري التحديث...' : nextAction.label}</span>
            </button>
          ) : (
            <div className="flex-1 py-3 px-4 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs text-center">
              {order.status === 'delivered' ? 'تم تسليم طلب الصيدلية بنجاح' : 'تم إلغاء طلب الصيدلية'}
            </div>
          )}

          <button
            onClick={onBack}
            className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition"
          >
            رجوع
          </button>
        </div>
      </div>
    </div>
  );
};
