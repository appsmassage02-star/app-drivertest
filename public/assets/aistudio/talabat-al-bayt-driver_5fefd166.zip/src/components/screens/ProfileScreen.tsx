import React, { useState } from 'react';
import {
  User,
  Car,
  Phone,
  ShieldCheck,
  Star,
  Database,
  Bell,
  LogOut,
  MapPin,
  MessageSquare,
} from 'lucide-react';
import { DriverProfile } from '../../types';
import { StatusBadge } from '../common/StatusBadge';

interface ProfileScreenProps {
  driver: DriverProfile;
  isSupabaseLive: boolean;
  onOpenSupabaseConfig: () => void;
  onLogout: () => void;
  onSwitchDriverType: (type: 'approved' | 'pending') => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  driver,
  isSupabaseLive,
  onOpenSupabaseConfig,
  onLogout,
  onSwitchDriverType,
}) => {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [autoAcceptEnabled, setAutoAcceptEnabled] = useState(false);

  return (
    <div className="space-y-4 pb-24 pt-4 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Profile Header Card */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-700 text-white flex items-center justify-center font-bold text-2xl overflow-hidden shadow-xs shrink-0 ring-4 ring-emerald-600/10">
            {driver.avatarUrl ? (
              <img
                src={driver.avatarUrl}
                alt={driver.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              driver.name.charAt(0) || 'ك'
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-slate-900 truncate">{driver.name}</h2>
              {driver.status === 'approved' && (
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              )}
            </div>
            <p className="text-xs text-slate-500 font-mono mt-0.5">{driver.phone}</p>
            <div className="pt-2 flex items-center gap-2.5">
              <StatusBadge status={driver.status} size="sm" />
              <span className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-2.5 py-0.5 rounded-lg flex items-center gap-1 font-mono">
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                {driver.rating.toFixed(2)} / 5.0
              </span>
            </div>
          </div>
        </div>

        {/* Vehicle and Zone Info */}
        <div className="grid sm:grid-cols-2 gap-2.5 pt-3 border-t border-slate-100 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-[11px] text-slate-400 font-bold flex items-center gap-1.5">
              <Car className="w-3.5 h-3.5 text-slate-500" />
              مركبة التوصيل
            </span>
            <p className="font-bold text-slate-900">{driver.vehicleModel || 'دراجة نارية / سيارة'}</p>
            <p className="text-[11px] text-slate-500 font-mono">{driver.vehiclePlate || 'أ ب ج 1234'}</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-[11px] text-slate-400 font-bold flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              نطاق التغطية والعمل
            </span>
            <p className="font-bold text-slate-900">{driver.workingZone || 'المنصورة وضواحيها'}</p>
            <p className="text-[11px] text-slate-500">تاريخ الانضمام: {driver.joinedDate || '2025'}</p>
          </div>
        </div>
      </div>

      {/* Database Connection & Persona Switcher */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900">ربط خادم Supabase</h3>
              <p className="text-xs text-slate-500">
                {isSupabaseLive ? 'متصل بقاعدة البيانات وقنوات Realtime الحية' : 'يعمل الآن بالوضع التجريبي المستقل'}
              </p>
            </div>
          </div>

          <button
            onClick={onOpenSupabaseConfig}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 font-bold text-xs transition"
          >
            إعداد الاتصال
          </button>
        </div>

        {/* Persona switch */}
        <div className="pt-3 border-t border-slate-100">
          <span className="text-xs font-bold text-slate-500 block mb-2">
            تجربة شاشات وحالات المندوب:
          </span>
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <button
              onClick={() => onSwitchDriverType('approved')}
              className={`p-2.5 rounded-xl text-center font-bold transition border ${
                driver.status === 'approved'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800 shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              كابتن معتمد نشط
            </button>
            <button
              onClick={() => onSwitchDriverType('pending')}
              className={`p-2.5 rounded-xl text-center font-bold transition border ${
                driver.status === 'pending'
                  ? 'bg-amber-50 border-amber-300 text-amber-800 shadow-xs'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              شاشة انتظار الاعتماد
            </button>
          </div>
        </div>
      </div>

      {/* Preferences */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3">
        <h3 className="font-bold text-sm text-slate-900">إعدادات التطبيق والتنبيهات</h3>

        <div className="space-y-3 text-xs divide-y divide-slate-100">
          <label className="flex items-center justify-between py-1 cursor-pointer">
            <div className="flex items-center gap-2.5">
              <Bell className="w-4 h-4 text-slate-500" />
              <span className="font-medium text-slate-800">التنبيهات الصوتية للطلبات الجديدة</span>
            </div>
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={(e) => setSoundEnabled(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-600 accent-emerald-600 cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between pt-3 cursor-pointer">
            <div className="flex items-center gap-2.5">
              <Car className="w-4 h-4 text-slate-500" />
              <span className="font-medium text-slate-800">القبول التلقائي للطلبات القريبة</span>
            </div>
            <input
              type="checkbox"
              checked={autoAcceptEnabled}
              onChange={(e) => setAutoAcceptEnabled(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-600 accent-emerald-600 cursor-pointer"
            />
          </label>
        </div>
      </div>

      {/* Support Actions */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3">
        <h3 className="font-bold text-sm text-slate-900">المساعدة والدعم التشغيلي</h3>
        <div className="grid grid-cols-2 gap-2.5 text-xs">
          <a
            href="https://wa.me/966500000000"
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center gap-2 transition"
          >
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <span>واتساب العمليات</span>
          </a>
          <a
            href="tel:920000000"
            className="p-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold flex items-center justify-center gap-2 transition"
          >
            <Phone className="w-4 h-4 text-slate-600" />
            <span>هاتف الطوارئ</span>
          </a>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={onLogout}
        className="w-full py-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 active:scale-[0.98] text-rose-700 font-bold text-xs flex items-center justify-center gap-2 border border-rose-200 transition"
      >
        <LogOut className="w-4 h-4" />
        <span>تسجيل الخروج من الحساب</span>
      </button>

      <div className="text-center text-xs text-slate-400 py-1 font-mono">
        Talabat Al-Bayt Driver v1.2.0 · منصة طلبات البيت
      </div>
    </div>
  );
};
