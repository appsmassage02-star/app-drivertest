import React, { useState } from 'react';
import { Truck, Lock, Mail, ArrowLeft, ShieldCheck, Clock, Database, Sparkles, AlertCircle } from 'lucide-react';
import { driverService } from '../../services/driverService';
import { isSupabaseConfigured } from '../../services/supabaseClient';

interface LoginScreenProps {
  onLoginSuccess: () => void;
  onOpenConfig: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess, onOpenConfig }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'demo' | 'supabase'>('demo');

  const isConfigured = isSupabaseConfigured();

  const handleDemoLogin = async (type: 'approved' | 'pending') => {
    setIsLoading(true);
    setErrorMessage('');
    try {
      const res = await driverService.loginWithDemo(type);
      if (res.success) {
        onLoginSuccess();
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'فشل تسجيل الدخول التجريبي');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSupabaseLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) {
      setErrorMessage('يرجى كتابة البريد الإلكتروني وكلمة المرور');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    const res = await driverService.loginWithSupabaseEmail(email, password);
    setIsLoading(false);

    if (res.success) {
      onLoginSuccess();
    } else {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-800 via-emerald-700 to-slate-900 text-white flex flex-col justify-between p-4 max-w-md mx-auto">
      {/* Top Bar with Connection Pill */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-1.5 text-xs text-emerald-200">
          <Truck className="w-4 h-4 text-emerald-300" />
          <span className="font-bold tracking-tight">طلبات البيت – تطبيق المندوب</span>
        </div>
        <button
          onClick={onOpenConfig}
          className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-900/80 border border-emerald-500/40 text-emerald-200 hover:bg-emerald-800 transition"
        >
          <Database className="w-3.5 h-3.5 text-emerald-300" />
          <span>{isConfigured ? 'Supabase متصل' : 'إعداد Supabase'}</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="my-auto py-6 space-y-6">
        {/* Logo and App Title */}
        <div className="text-center space-y-2">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-white text-emerald-700 shadow-xl flex items-center justify-center transform -rotate-3 hover:rotate-0 transition-transform">
            <Truck className="w-10 h-10 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white pt-2">
            طلبات البيت للمندوب
          </h1>
          <p className="text-xs text-emerald-100 max-w-xs mx-auto leading-relaxed">
            بوابة الكابتن لاستقبال وتوصيل طلبات المطاعم والمتاجر والأدوية والصيدليات
          </p>
        </div>

        {/* Tab Switcher: Demo vs Supabase */}
        <div className="bg-emerald-900/60 p-1 rounded-2xl flex border border-emerald-600/40 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('demo')}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'demo'
                ? 'bg-white text-emerald-900 shadow-sm'
                : 'text-emerald-100 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>الدخول التجريبي الفوري</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('supabase')}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              activeTab === 'supabase'
                ? 'bg-white text-emerald-900 shadow-sm'
                : 'text-emerald-100 hover:text-white'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-600" />
            <span>حساب Supabase الحقيقي</span>
          </button>
        </div>

        {/* Error Feedback */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-400 text-rose-100 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Mode 1: Fast Demo Login Cards */}
        {activeTab === 'demo' ? (
          <div className="space-y-3">
            <button
              onClick={() => handleDemoLogin('approved')}
              disabled={isLoading}
              className="w-full text-right p-4 rounded-2xl bg-white text-slate-800 shadow-lg hover:shadow-xl active:scale-[0.98] transition border-2 border-emerald-400 flex items-center justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-emerald-900">
                    أحمد مصطفى التميمي
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    كابتن معتمد نشط
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  دخول مباشر بحساب جاهز لاستقبال وتنفيذ الطلبات العادية والصيدلية
                </p>
              </div>
              <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition">
                <ArrowLeft className="w-4 h-4" />
              </div>
            </button>

            <button
              onClick={() => handleDemoLogin('pending')}
              disabled={isLoading}
              className="w-full text-right p-4 rounded-2xl bg-white/95 text-slate-800 shadow-md hover:shadow-lg active:scale-[0.98] transition border border-amber-300 flex items-center justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-800">
                    سامي كمال النجار
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-amber-600" />
                    حساب قيد مراجعة الاعتماد
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  معاينة شاشة انتظار اعتماد الحساب ومتابعة حالة المستندات
                </p>
              </div>
              <div className="w-8 h-8 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition">
                <ArrowLeft className="w-4 h-4" />
              </div>
            </button>
          </div>
        ) : (
          /* Mode 2: Live Supabase Login */
          <form onSubmit={handleSupabaseLogin} className="space-y-3.5 bg-white p-5 rounded-2xl text-slate-800 shadow-xl">
            {!isConfigured && (
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[11px] mb-2">
                لم يتم إعداد رابط ومفتاح Supabase في التطبيق. يمكنك الضغط على "إعداد Supabase" بأعلى الشاشة لإدخالهما.
              </div>
            )}

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">
                البريد الإلكتروني للمندوب
              </label>
              <div className="relative">
                <input
                  type="email"
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="driver@example.com"
                  className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-200 text-xs font-mono focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none text-left"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">
                كلمة المرور
              </label>
              <div className="relative">
                <input
                  type="password"
                  dir="ltr"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 pl-9 rounded-xl border border-slate-200 text-xs font-mono focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 outline-none text-left"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:scale-98 text-white font-bold text-xs transition shadow-md disabled:opacity-50 mt-2"
            >
              {isLoading ? 'جاري التحقق من بيانات الدخول...' : 'تسجيل الدخول عبر Supabase'}
            </button>
          </form>
        )}
      </div>

      {/* Footer Info */}
      <div className="text-center text-[11px] text-emerald-200/80 py-2">
        الإصدار 1.2.0 • منصة طلبات البيت الرسمية
      </div>
    </div>
  );
};
