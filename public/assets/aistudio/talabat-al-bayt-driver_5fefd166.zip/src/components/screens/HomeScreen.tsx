import React from 'react';
import {
  Wallet,
  TrendingUp,
  Star,
  Package,
  Pill,
  MapPin,
  Clock,
  Sparkles,
  Check,
  ChevronLeft,
  Navigation,
  ArrowUpRight,
  Store,
  Snowflake,
} from 'lucide-react';
import { DriverProfile, DeliveryOrder, PharmacyOrder } from '../../types';
import { StatusBadge } from '../common/StatusBadge';
import { ordersService } from '../../services/ordersService';

interface HomeScreenProps {
  driver: DriverProfile;
  regularOrders: DeliveryOrder[];
  pharmacyOrders: PharmacyOrder[];
  onNavigateTab: (tab: 'orders' | 'pharmacy' | 'history' | 'profile') => void;
  onOpenRegularOrder: (order: DeliveryOrder) => void;
  onOpenPharmacyOrder: (order: PharmacyOrder) => void;
  onAcceptOrder: (orderId: string, type: 'regular' | 'pharmacy') => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  driver,
  regularOrders,
  pharmacyOrders,
  onNavigateTab,
  onOpenRegularOrder,
  onOpenPharmacyOrder,
  onAcceptOrder,
}) => {
  const isOnline = driver.availability === 'online';

  // Find active orders currently in progress
  const activeRegular = regularOrders.find(
    (o) => o.status === 'accepted' || o.status === 'picked_up' || o.status === 'in_transit'
  );
  const activePharmacy = pharmacyOrders.find(
    (o) => o.status === 'accepted' || o.status === 'picked_up' || o.status === 'in_transit'
  );
  const activeOrder = activeRegular || activePharmacy;

  // Find new orders waiting for response
  const newRegularOrders = regularOrders.filter((o) => o.status === 'new');
  const newPharmacyOrders = pharmacyOrders.filter((o) => o.status === 'new');
  const totalNewOrders = newRegularOrders.length + newPharmacyOrders.length;

  return (
    <div className="space-y-5 pb-24 pt-4 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Availability Status Card */}
      <div
        className={`p-4 rounded-2xl border transition-all duration-200 flex items-center justify-between shadow-xs ${
          isOnline
            ? 'bg-emerald-600 text-white border-emerald-500 shadow-emerald-900/10'
            : 'bg-slate-900 text-slate-100 border-slate-800'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-3.5 h-3.5 rounded-full ${
              isOnline ? 'bg-emerald-300 ring-4 ring-white/20' : 'bg-amber-400 ring-4 ring-amber-400/20'
            }`}
          />
          <div>
            <h2 className="text-sm font-bold leading-tight">
              {isOnline ? 'أنت متصل بالخدمة (متاح لاستقبال الطلبات)' : 'أنت غير متصل (أوفلاين)'}
            </h2>
            <p className="text-xs opacity-90 mt-0.5">
              {isOnline
                ? 'يتم عرض وتوجيه الطلبات القريبة منك لحظياً'
                : 'اضغط على زر (متاح الآن) في الشريط العلوي لبدء استقبال الطلبات'}
            </p>
          </div>
        </div>
      </div>

      {/* KPI Performance Metrics */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-xs font-bold text-slate-500">مؤشرات الأداء اليومي</h2>
          <span className="text-xs text-slate-400 font-mono">اليوم</span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">أرباح اليوم</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-900 font-mono tabular-nums tracking-tight">
                {driver.todayEarnings.toFixed(2)}
              </span>
              <span className="text-xs font-bold text-slate-500">ر.س</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">مشاوير منجزة</span>
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
                <Package className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-900 font-mono tabular-nums tracking-tight">
                {driver.todayTrips}
              </span>
              <span className="text-xs font-bold text-slate-500">مشوار</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">رصيد المحفظة</span>
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-900 font-mono tabular-nums tracking-tight">
                {driver.walletBalance.toFixed(2)}
              </span>
              <span className="text-xs font-bold text-slate-500">ر.س</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold">تقييم الكابتن</span>
              <div className="w-8 h-8 rounded-lg bg-violet-50 text-violet-700 flex items-center justify-center">
                <Star className="w-4 h-4 fill-violet-600 text-violet-600" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-900 font-mono tabular-nums tracking-tight">
                {driver.rating.toFixed(2)}
              </span>
              <span className="text-xs font-bold text-slate-500">/ 5.0</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Order Spotlight (If Exists) */}
      {activeOrder && (
        <div className="p-5 rounded-2xl bg-white border-2 border-emerald-600 shadow-md space-y-4 relative">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
              <span className="text-sm font-bold text-slate-900">مشوار نشط قيد التنفيذ الآن</span>
            </div>
            <StatusBadge status={activeOrder.status} size="sm" />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-700 shrink-0" />
                <h3 className="font-bold text-base text-slate-900">
                  {activeOrder.store.name}
                </h3>
              </div>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>المتجر: {activeOrder.store.address}</span>
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="text-xs font-semibold text-slate-600">وجهة العميل:</div>
              <p className="text-xs text-slate-700 font-medium flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="truncate">{activeOrder.customer.address}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-100">
            <div className="flex items-center gap-3 text-slate-600">
              <span>{activeOrder.itemsCount} أصناف</span>
              <span>·</span>
              <span>{activeOrder.distanceKm} كم المسافة</span>
              <span>·</span>
              <span className="font-mono font-bold text-slate-800">#{activeOrder.orderNumber}</span>
            </div>
            <div className="text-sm font-bold text-emerald-700 font-mono">
              +{activeOrder.driverFee.toFixed(2)} ر.س
            </div>
          </div>

          <button
            onClick={() => {
              if (activeOrder.type === 'pharmacy') {
                onOpenPharmacyOrder(activeOrder as PharmacyOrder);
              } else {
                onOpenRegularOrder(activeOrder);
              }
            }}
            className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-xs"
          >
            <Navigation className="w-4 h-4" />
            <span>متابعة تفاصيل وإجراءات الطلب</span>
          </button>
        </div>
      )}

      {/* Incoming Available Orders Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-slate-900">الطلبات المتاحة للقبول</h2>
            {totalNewOrders > 0 && (
              <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
                {totalNewOrders} طلب جديد
              </span>
            )}
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 transition flex items-center gap-0.5"
          >
            <span>عرض كل الطلبات</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {totalNewOrders === 0 ? (
          <div className="p-8 rounded-2xl bg-white border border-slate-200/80 text-center space-y-2.5">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">لا توجد طلبات جديدة معلقة حالياً</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
              تصل الطلبات فور تأكيد العملاء. حافظ على حالة اتصالك لاستقبال الطلبات القريبة مباشرة.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3.5">
            {/* Regular Orders */}
            {newRegularOrders.map((order) => (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:border-emerald-300 hover:shadow-sm transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                      <Package className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{order.store.name}</h4>
                      <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <span>{order.store.area}</span>
                        <span>➔</span>
                        <span>{order.customer.area}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-emerald-700 font-mono block">
                      +{order.driverFee} ر.س
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">أجرة التوصيل</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-500 pt-1 border-t border-slate-100">
                  <span>{order.itemsCount} أصناف</span>
                  <span>·</span>
                  <span>{order.distanceKm} كم</span>
                  <span>·</span>
                  <span>{order.paymentMethod === 'cash' ? 'كاش' : 'إلكتروني'}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => onAcceptOrder(order.id, 'regular')}
                    className="h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                  >
                    <Check className="w-4 h-4" />
                    <span>قبول الطلب</span>
                  </button>
                  <button
                    onClick={() => onOpenRegularOrder(order)}
                    className="h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-[0.98] text-slate-700 font-bold text-xs transition"
                  >
                    التفاصيل
                  </button>
                </div>
              </div>
            ))}

            {/* Pharmacy Orders */}
            {newPharmacyOrders.map((order) => (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-white border border-rose-200/90 shadow-xs hover:border-rose-400 hover:shadow-sm transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
                      <Pill className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-sm text-slate-900">{order.store.name}</h4>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                          صيدلية
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <span>{order.store.area}</span>
                        <span>➔</span>
                        <span>{order.customer.area}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-rose-700 font-mono block">
                      +{order.driverFee} ر.س
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">أجرة التوصيل</span>
                  </div>
                </div>

                {order.hasColdStorageMedicines && (
                  <div className="flex items-center gap-1.5 text-xs text-sky-800 bg-sky-50 px-2.5 py-1.5 rounded-lg border border-sky-200">
                    <Snowflake className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                    <span className="font-medium">أدوية تتطلب حفظ مبرد (حافظة ثلج)</span>
                  </div>
                )}

                <div className="flex items-center gap-3 text-xs text-slate-500 pt-1 border-t border-slate-100">
                  <span>{order.itemsCount} أصناف</span>
                  <span>·</span>
                  <span>{order.distanceKm} كم</span>
                  <span>·</span>
                  <span>{order.needsPrescription ? 'روشتة مطلوبة' : 'أدوية مباشرة'}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => onAcceptOrder(order.id, 'pharmacy')}
                    className="h-10 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                  >
                    <Check className="w-4 h-4" />
                    <span>قبول طلب الصيدلية</span>
                  </button>
                  <button
                    onClick={() => onOpenPharmacyOrder(order)}
                    className="h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-[0.98] text-slate-700 font-bold text-xs transition"
                  >
                    التفاصيل
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Simulator Quick Action Drawer */}
      <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <Sparkles className="w-4 h-4" />
            <span>محاكاة وصول طلب جديد لحظي</span>
          </div>
          <p className="text-xs text-slate-300 mt-0.5">
            اختبر استلام ومعالجة الطلبات محلياً في بيئة التطوير
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => ordersService.injectDemoNewOrder('regular')}
            className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition active:scale-95 shadow-xs"
          >
            + طلب مطعم
          </button>
          <button
            onClick={() => ordersService.injectDemoNewOrder('pharmacy')}
            className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white transition active:scale-95 shadow-xs"
          >
            + طلب صيدلية
          </button>
        </div>
      </div>
    </div>
  );
};
