import React, { useState, useMemo } from 'react';
import { Package, Search, MapPin, Check, ArrowLeft, RefreshCw } from 'lucide-react';
import { DeliveryOrder } from '../../types';
import { StatusBadge } from '../common/StatusBadge';

interface OrdersScreenProps {
  orders: DeliveryOrder[];
  onOpenOrder: (order: DeliveryOrder) => void;
  onAcceptOrder: (orderId: string) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  orders,
  onOpenOrder,
  onAcceptOrder,
  onRefresh,
  isRefreshing,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'active' | 'completed'>('all');

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        order.orderNumber.toLowerCase().includes(q) ||
        order.store.name.toLowerCase().includes(q) ||
        order.customer.name.toLowerCase().includes(q) ||
        order.customer.area.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      if (statusFilter === 'all') return true;
      if (statusFilter === 'new') return order.status === 'new';
      if (statusFilter === 'active')
        return order.status === 'accepted' || order.status === 'picked_up' || order.status === 'in_transit';
      if (statusFilter === 'completed')
        return order.status === 'delivered' || order.status === 'cancelled';

      return true;
    });
  }, [orders, searchQuery, statusFilter]);

  const newCount = orders.filter((o) => o.status === 'new').length;
  const activeCount = orders.filter(
    (o) => o.status === 'accepted' || o.status === 'picked_up' || o.status === 'in_transit'
  ).length;
  const completedCount = orders.filter(
    (o) => o.status === 'delivered' || o.status === 'cancelled'
  ).length;

  return (
    <div className="space-y-4 pb-24 pt-4 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Title & Total Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">طلبات التوصيل العادية</h2>
          <p className="text-xs text-slate-500">طلبات المطاعم، السوبرماركت، والمتاجر التجارية</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-600 bg-white border border-slate-200 px-3 py-1 rounded-xl shadow-xs tabular-nums">
            {orders.length} طلبات
          </span>
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="w-8 h-8 rounded-xl bg-white border border-slate-200 text-slate-600 hover:text-slate-900 flex items-center justify-center transition disabled:opacity-50"
            title="تحديث"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث برقم الطلب، اسم المتجر، الحي أو اسم العميل..."
          className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-white border border-slate-200/90 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 outline-none shadow-xs transition"
        />
        <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
      </div>

      {/* Segmented Filter Control */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setStatusFilter('all')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'all'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          الكل ({orders.length})
        </button>
        <button
          onClick={() => setStatusFilter('new')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'new'
              ? 'bg-white text-emerald-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          جديدة ({newCount})
        </button>
        <button
          onClick={() => setStatusFilter('active')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'active'
              ? 'bg-white text-blue-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          قيد التنفيذ ({activeCount})
        </button>
        <button
          onClick={() => setStatusFilter('completed')}
          className={`flex-1 min-w-[70px] py-1.5 px-3 rounded-lg whitespace-nowrap transition-all text-center ${
            statusFilter === 'completed'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          مكتملة ({completedCount})
        </button>
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <div className="py-14 px-4 text-center bg-white rounded-2xl border border-slate-200/80 space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Package className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">لا توجد طلبات مطابقة</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              جرب تغيير خيارات التصفية أو البحث لعرض باقي طلبات التوصيل.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-3.5">
          {filteredOrders.map((order) => {
            const isNew = order.status === 'new';

            return (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:border-slate-300 transition-all space-y-3 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                        <Package className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 leading-tight">
                          {order.store.name}
                        </h3>
                        <span className="text-[11px] font-mono font-medium text-slate-400">
                          #{order.orderNumber}
                        </span>
                      </div>
                    </div>
                    <StatusBadge status={order.status} size="sm" />
                  </div>

                  {/* Route Details */}
                  <div className="space-y-1.5 text-xs text-slate-600 bg-slate-50/80 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />
                      <span className="text-slate-400">المتجر:</span>
                      <span className="font-semibold text-slate-800 truncate">{order.store.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                      <span className="text-slate-400">العميل:</span>
                      <span className="font-semibold text-slate-800 truncate">{order.customer.address}</span>
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-2">
                      <span>{order.itemsCount} أصناف</span>
                      <span>·</span>
                      <span>{order.distanceKm} كم</span>
                      <span>·</span>
                      <span className={order.isPaid ? 'text-emerald-700 font-semibold' : 'text-amber-800 font-semibold'}>
                        {order.isPaid ? 'مدفوع إلكترونياً' : 'نقداً عند الاستلام'}
                      </span>
                    </div>
                    <div className="text-sm font-black text-emerald-700 font-mono">
                      +{order.driverFee.toFixed(2)} ر.س
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-2 border-t border-slate-100">
                  {isNew ? (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => onAcceptOrder(order.id)}
                        className="h-10 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
                      >
                        <Check className="w-4 h-4" />
                        <span>قبول الطلب</span>
                      </button>
                      <button
                        onClick={() => onOpenOrder(order)}
                        className="h-10 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-[0.98] text-slate-700 font-bold text-xs transition"
                      >
                        التفاصيل
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => onOpenOrder(order)}
                      className="w-full h-10 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-xs"
                    >
                      <span>متابعة تفاصيل الطلب والتنقل</span>
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
