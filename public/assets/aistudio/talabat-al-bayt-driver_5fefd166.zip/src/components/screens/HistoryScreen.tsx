import React, { useState, useMemo } from 'react';
import { Clock, Search, Package, Pill } from 'lucide-react';
import { DeliveryOrder } from '../../types';

interface HistoryScreenProps {
  orders: DeliveryOrder[];
  onOpenOrder: (order: DeliveryOrder) => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ orders, onOpenOrder }) => {
  const [filterType, setFilterType] = useState<'all' | 'regular' | 'pharmacy'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredHistory = useMemo(() => {
    return orders.filter((o) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        o.orderNumber.toLowerCase().includes(q) ||
        o.store.name.toLowerCase().includes(q) ||
        o.customer.name.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      if (filterType === 'all') return true;
      return o.type === filterType;
    });
  }, [orders, filterType, searchQuery]);

  // Aggregate stats
  const totalEarned = useMemo(() => {
    return orders
      .filter((o) => o.status === 'delivered')
      .reduce((acc, curr) => acc + (curr.driverFee || 0), 0);
  }, [orders]);

  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;

  return (
    <div className="space-y-4 pb-24 pt-4 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">سجل الطلبات والمشاوير</h2>
          <p className="text-xs text-slate-500">أرشيف الطلبات المنجزة وسجل الأرباح المحققة</p>
        </div>
        <span className="text-xs font-bold text-slate-700 bg-white border border-slate-200 px-3 py-1 rounded-xl shadow-xs tabular-nums">
          {orders.length} طلبات
        </span>
      </div>

      {/* Aggregate KPI Strip */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block">إجمالي أرباح السجل</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-emerald-700 font-mono tabular-nums tracking-tight">
              {totalEarned.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-slate-500">ر.س</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block">مشاوير ناجحة</span>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-2xl font-black text-slate-900 font-mono tabular-nums tracking-tight">
              {deliveredCount}
            </span>
            <span className="text-xs font-bold text-slate-500">تم التسليم</span>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث برقم الطلب، اسم المتجر أو العميل..."
          className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-white border border-slate-200/90 text-xs text-slate-800 placeholder-slate-400 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 outline-none shadow-xs transition"
        />
        <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
      </div>

      {/* Type Filter Segmented Control */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl text-xs font-bold">
        <button
          onClick={() => setFilterType('all')}
          className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
            filterType === 'all'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          الكل ({orders.length})
        </button>
        <button
          onClick={() => setFilterType('regular')}
          className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            filterType === 'regular'
              ? 'bg-white text-emerald-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>مطاعم ومتاجر</span>
        </button>
        <button
          onClick={() => setFilterType('pharmacy')}
          className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
            filterType === 'pharmacy'
              ? 'bg-white text-rose-800 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Pill className="w-3.5 h-3.5" />
          <span>صيدليات</span>
        </button>
      </div>

      {/* History List */}
      {filteredHistory.length === 0 ? (
        <div className="py-14 px-4 text-center bg-white rounded-2xl border border-slate-200/80 space-y-2.5">
          <Clock className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-sm font-bold text-slate-700">لا توجد طلبات سابقة مطابقة</p>
          <p className="text-xs text-slate-400">ستظهر هنا المشاوير التي تقوم بإنهائها وتسليمها للعملاء.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {filteredHistory.map((order) => {
            const isDelivered = order.status === 'delivered';
            const isPharmacy = order.type === 'pharmacy';

            return (
              <div
                key={order.id}
                onClick={() => onOpenOrder(order)}
                className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:border-slate-300 transition-all cursor-pointer space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                        isPharmacy ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'
                      }`}
                    >
                      {isPharmacy ? <Pill className="w-4 h-4" /> : <Package className="w-4 h-4" />}
                    </span>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 leading-tight">
                        {order.store.name}
                      </h4>
                      <span className="text-[11px] font-mono text-slate-400">
                        #{order.orderNumber} · {order.createdAt}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-black text-emerald-700 font-mono block">
                      +{order.driverFee.toFixed(2)} ر.س
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {isDelivered ? 'تم التسليم ✓' : 'ملغي'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <span className="truncate">العميل: {order.customer.name} ({order.customer.area})</span>
                  <span className="font-medium text-slate-400 shrink-0">
                    {order.distanceKm} كم
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
