import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/common/Header';
import { BottomNav, TabType } from './components/common/BottomNav';
import { SupabaseConfigModal } from './components/common/SupabaseConfigModal';
import { LoginScreen } from './components/screens/LoginScreen';
import { PendingApprovalScreen } from './components/screens/PendingApprovalScreen';
import { HomeScreen } from './components/screens/HomeScreen';
import { OrdersScreen } from './components/screens/OrdersScreen';
import { OrderDetailsScreen } from './components/screens/OrderDetailsScreen';
import { PharmacyOrdersScreen } from './components/screens/PharmacyOrdersScreen';
import { PharmacyDetailsScreen } from './components/screens/PharmacyDetailsScreen';
import { HistoryScreen } from './components/screens/HistoryScreen';
import { ProfileScreen } from './components/screens/ProfileScreen';

import { DriverProfile, DeliveryOrder, PharmacyOrder, OrderStatus } from './types';
import { driverService } from './services/driverService';
import { ordersService } from './services/ordersService';
import { isSupabaseConfigured } from './services/supabaseClient';

export default function App() {
  // Authentication & Driver state
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [driver, setDriver] = useState<DriverProfile>(driverService['currentProfile']);

  // Navigation state
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [selectedRegularOrder, setSelectedRegularOrder] = useState<DeliveryOrder | null>(null);
  const [selectedPharmacyOrder, setSelectedPharmacyOrder] = useState<PharmacyOrder | null>(null);

  // Orders state
  const [regularOrders, setRegularOrders] = useState<DeliveryOrder[]>([]);
  const [pharmacyOrders, setPharmacyOrders] = useState<PharmacyOrder[]>([]);
  const [historyOrders, setHistoryOrders] = useState<DeliveryOrder[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Supabase state
  const [isSupabaseLive, setIsSupabaseLive] = useState(isSupabaseConfigured());
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  // Toast notification helper
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Load orders
  const loadOrders = useCallback(async () => {
    const [reg, phr, hist] = await Promise.all([
      ordersService.getRegularOrders(),
      ordersService.getPharmacyOrders(),
      ordersService.getHistoryOrders(),
    ]);
    setRegularOrders(reg);
    setPharmacyOrders(phr);
    setHistoryOrders(hist);

    // Keep selected order in sync if currently viewing one
    if (selectedRegularOrder) {
      const updated = reg.find((o) => o.id === selectedRegularOrder.id);
      if (updated) setSelectedRegularOrder(updated);
    }
    if (selectedPharmacyOrder) {
      const updated = phr.find((o) => o.id === selectedPharmacyOrder.id);
      if (updated) setSelectedPharmacyOrder(updated);
    }
  }, [selectedRegularOrder, selectedPharmacyOrder]);

  // Initial setup & subscriptions
  useEffect(() => {
    // Subscribe to driver profile changes
    const unsubDriver = driverService.onProfileChange((profile) => {
      setDriver(profile);
      ordersService.setDriverSession(profile.id, {
        governorate: profile.governorate,
        center: profile.center,
      });
    });

    // Subscribe to live orders updates (Requirement 9: updates UI directly)
    const unsubOrders = ordersService.subscribe(() => {
      loadOrders();
    });

    loadOrders();
    setIsSupabaseLive(isSupabaseConfigured());

    return () => {
      unsubDriver();
      unsubOrders();
    };
  }, [loadOrders]);

  // Handle manual refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([
      ordersService.refreshOrders(),
      driverService.getDriverProfile(),
    ]);
    await loadOrders();
    setTimeout(() => {
      setIsRefreshing(false);
      showToast('تم تحديث البيانات بنجاح ✓');
    }, 500);
  };

  // Handle availability toggle
  const handleToggleAvailability = async () => {
    const nextAvailability = driver.availability === 'online' ? 'offline' : 'online';
    await driverService.updateAvailability(nextAvailability);
    showToast(nextAvailability === 'online' ? 'أنت متصل الآن لاستقبال الطلبات' : 'تم تحويل الحالة إلى غير متاح');
  };

  // Handle accepting order
  const handleAcceptOrder = async (orderId: string, type: 'regular' | 'pharmacy' = 'regular') => {
    await ordersService.updateOrderStatus(orderId, 'accepted', type);
    showToast('تم قبول الطلب بنجاح! انتقل للمتجر للاستلام');
  };

  // Handle updating order status
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus, type: 'regular' | 'pharmacy' = 'regular') => {
    await ordersService.updateOrderStatus(orderId, status, type);
    if (status === 'delivered') {
      showToast('تهانينا! تم تسليم الطلب بنجاح وإضافة الأجرة إلى محفظتك');
      // If was viewing details, return to list
      setSelectedRegularOrder(null);
      setSelectedPharmacyOrder(null);
    } else {
      showToast('تم تحديث حالة الطلب بنجاح');
    }
    loadOrders();
  };

  // Counts for bottom navigation
  const newRegularCount = regularOrders.filter((o) => o.status === 'new').length;
  const newPharmacyCount = pharmacyOrders.filter((o) => o.status === 'new').length;

  // View state determination
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-900 flex justify-center">
        <LoginScreen
          onLoginSuccess={() => {
            setIsLoggedIn(true);
            showToast('تم تسجيل الدخول بنجاح');
          }}
          onOpenConfig={() => setIsConfigModalOpen(true)}
        />
        <SupabaseConfigModal
          isOpen={isConfigModalOpen}
          onClose={() => setIsConfigModalOpen(false)}
          onConfigChanged={() => {
            setIsSupabaseLive(isSupabaseConfigured());
            loadOrders();
          }}
        />
      </div>
    );
  }

  // If driver status is pending, show Pending Approval Screen
  if (driver.status === 'pending') {
    return (
      <div className="min-h-screen bg-slate-100 flex justify-center">
        <div className="w-full max-w-md bg-white min-h-screen shadow-2xl relative flex flex-col">
          <PendingApprovalScreen
            driver={driver}
            onRefresh={handleRefresh}
            onLogout={() => {
              driverService.logout();
              setIsLoggedIn(false);
            }}
            onSwitchToApproved={() => {
              driverService.switchDemoDriver('approved');
              showToast('تم التحويل إلى حساب كابتن معتمد نشط');
            }}
          />
          <SupabaseConfigModal
            isOpen={isConfigModalOpen}
            onClose={() => setIsConfigModalOpen(false)}
            onConfigChanged={() => {
              setIsSupabaseLive(isSupabaseConfigured());
              loadOrders();
            }}
          />
        </div>
      </div>
    );
  }

  // Main Authenticated View
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col selection:bg-emerald-200 font-sans">
      <div className="w-full flex-1 flex flex-col min-h-screen">
        {/* Android Header */}
        <Header
          driver={driver}
          showBack={Boolean(selectedRegularOrder || selectedPharmacyOrder)}
          title={
            selectedRegularOrder
              ? `طلب ${selectedRegularOrder.orderNumber}`
              : selectedPharmacyOrder
              ? `صيدلية ${selectedPharmacyOrder.orderNumber}`
              : undefined
          }
          onBack={() => {
            setSelectedRegularOrder(null);
            setSelectedPharmacyOrder(null);
          }}
          onToggleAvailability={handleToggleAvailability}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
          onOpenSupabaseConfig={() => setIsConfigModalOpen(true)}
          isSupabaseLive={isSupabaseLive}
        />

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-xl border border-slate-700/80 animate-in fade-in slide-in-from-top-2 duration-200 flex items-center gap-2 max-w-[90%] text-center">
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Screen Routing */}
        <main className="flex-1 overflow-y-auto">
          {/* Detail screens take precedence */}
          {selectedRegularOrder ? (
            <OrderDetailsScreen
              order={selectedRegularOrder}
              onBack={() => setSelectedRegularOrder(null)}
              onUpdateStatus={(id, status) => handleUpdateOrderStatus(id, status, 'regular')}
            />
          ) : selectedPharmacyOrder ? (
            <PharmacyDetailsScreen
              order={selectedPharmacyOrder}
              onBack={() => setSelectedPharmacyOrder(null)}
              onUpdateStatus={(id, status) => handleUpdateOrderStatus(id, status, 'pharmacy')}
            />
          ) : (
            <>
              {/* Tab 1: Home Screen */}
              {activeTab === 'home' && (
                <HomeScreen
                  driver={driver}
                  regularOrders={regularOrders}
                  pharmacyOrders={pharmacyOrders}
                  onNavigateTab={(tab) => setActiveTab(tab)}
                  onOpenRegularOrder={(order) => setSelectedRegularOrder(order)}
                  onOpenPharmacyOrder={(order) => setSelectedPharmacyOrder(order)}
                  onAcceptOrder={(id, type) => handleAcceptOrder(id, type)}
                />
              )}

              {/* Tab 2: Regular Orders Screen */}
              {activeTab === 'orders' && (
                <OrdersScreen
                  orders={regularOrders}
                  onOpenOrder={(order) => setSelectedRegularOrder(order)}
                  onAcceptOrder={(id) => handleAcceptOrder(id, 'regular')}
                  onRefresh={handleRefresh}
                  isRefreshing={isRefreshing}
                />
              )}

              {/* Tab 3: Pharmacy Orders Screen */}
              {activeTab === 'pharmacy' && (
                <PharmacyOrdersScreen
                  orders={pharmacyOrders}
                  onOpenOrder={(order) => setSelectedPharmacyOrder(order)}
                  onAcceptOrder={(id) => handleAcceptOrder(id, 'pharmacy')}
                  onRefresh={handleRefresh}
                  isRefreshing={isRefreshing}
                />
              )}

              {/* Tab 4: History Screen */}
              {activeTab === 'history' && (
                <HistoryScreen
                  orders={historyOrders}
                  onOpenOrder={(order) => {
                    if (order.type === 'pharmacy') {
                      setSelectedPharmacyOrder(order as PharmacyOrder);
                    } else {
                      setSelectedRegularOrder(order);
                    }
                  }}
                />
              )}

              {/* Tab 5: Profile Screen */}
              {activeTab === 'profile' && (
                <ProfileScreen
                  driver={driver}
                  isSupabaseLive={isSupabaseLive}
                  onOpenSupabaseConfig={() => setIsConfigModalOpen(true)}
                  onLogout={() => {
                    driverService.logout();
                    setIsLoggedIn(false);
                  }}
                  onSwitchDriverType={(type) => {
                    driverService.switchDemoDriver(type);
                    showToast(type === 'approved' ? 'تم اختيار كابتن معتمد' : 'تم اختيار كابتن قيد الاعتماد');
                  }}
                />
              )}
            </>
          )}
        </main>

        {/* Bottom Navigation */}
        {!selectedRegularOrder && !selectedPharmacyOrder && (
          <BottomNav
            activeTab={activeTab}
            onChangeTab={(tab) => setActiveTab(tab)}
            regularOrdersCount={newRegularCount}
            pharmacyOrdersCount={newPharmacyCount}
          />
        )}

        {/* Supabase Config Modal */}
        <SupabaseConfigModal
          isOpen={isConfigModalOpen}
          onClose={() => setIsConfigModalOpen(false)}
          onConfigChanged={() => {
            setIsSupabaseLive(isSupabaseConfigured());
            loadOrders();
          }}
        />
      </div>
    </div>
  );
}
