import fs from 'node:fs';
import path from 'node:path';
import 'dotenv/config';

async function run() {
  const rawUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '';
  const apiKey = (
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    ''
  ).trim();

  if (!rawUrl) {
    console.error(JSON.stringify({
      success: false,
      error: 'Missing SUPABASE_URL / VITE_SUPABASE_URL environment variable'
    }));
    process.exit(1);
  }

  if (!apiKey) {
    console.error(JSON.stringify({
      success: false,
      error: 'Missing SUPABASE_ANON_KEY / VITE_SUPABASE_ANON_KEY environment variable'
    }));
    process.exit(1);
  }

  let parsedHost = '';
  try {
    parsedHost = new URL(rawUrl).host;
  } catch (err) {
    console.error(JSON.stringify({
      success: false,
      error: 'Invalid SUPABASE_URL format'
    }));
    process.exit(1);
  }

  const endpoint = `${rawUrl.replace(/\/+$/, '')}/rest/v1/`;

  try {
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: {
        'apikey': apiKey,
        'Authorization': `Bearer ${apiKey}`,
        'Accept': 'application/openapi+json, application/json'
      }
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      // Ensure no apiKey is present in errText
      const sanitizedErr = errText.replaceAll(apiKey, '[REDACTED]');
      console.error(JSON.stringify({
        success: false,
        status: res.status,
        statusText: res.statusText,
        host: parsedHost,
        error: sanitizedErr.slice(0, 500)
      }));
      process.exit(1);
    }

    const openapi = await res.json();

    // Analyze OpenAPI document
    const paths = openapi.paths || {};
    const definitions = openapi.definitions || (openapi.components && openapi.components.schemas) || {};

    const tables = [];
    const rpcFunctions = [];

    for (const [routePath, methods] of Object.entries(paths)) {
      if (routePath.startsWith('/rpc/')) {
        const rpcName = routePath.replace('/rpc/', '');
        const methodInfo = methods.post || methods.get || {};
        const parameters = [];

        if (Array.isArray(methodInfo.parameters)) {
          for (const param of methodInfo.parameters) {
            if (param.in === 'body' && param.schema) {
              const schemaRef = param.schema.$ref;
              const defName = schemaRef ? schemaRef.replace('#/definitions/', '').replace('#/components/schemas/', '') : '';
              const defObj = defName ? definitions[defName] : param.schema;
              if (defObj && defObj.properties) {
                for (const [propName, propDef] of Object.entries(defObj.properties)) {
                  parameters.push({
                    name: propName,
                    type: propDef.type || propDef.format || 'unknown',
                    description: propDef.description || '',
                    required: Array.isArray(defObj.required) && defObj.required.includes(propName)
                  });
                }
              }
            } else if (param.name) {
              parameters.push({
                name: param.name,
                type: param.type || param.format || 'unknown',
                description: param.description || '',
                required: Boolean(param.required)
              });
            }
          }
        }

        let returnType = 'void';
        if (methodInfo.responses && methodInfo.responses['200']) {
          const resp = methodInfo.responses['200'];
          if (resp.schema) {
            returnType = resp.schema.type || (resp.schema.$ref ? resp.schema.$ref.split('/').pop() : 'object');
          }
        }

        rpcFunctions.push({
          name: rpcName,
          httpMethod: methods.post ? 'POST' : 'GET',
          summary: methodInfo.summary || methodInfo.description || '',
          parameters,
          returnType
        });
      } else if (routePath !== '/') {
        const tableName = routePath.replace(/^\//, '');
        const supportedMethods = Object.keys(methods).map(m => m.toUpperCase());
        const def = definitions[tableName];
        const columns = [];

        if (def && def.properties) {
          for (const [colName, colDef] of Object.entries(def.properties)) {
            columns.push({
              name: colName,
              type: colDef.type || 'unknown',
              format: colDef.format || '',
              description: colDef.description || '',
              required: Array.isArray(def.required) && def.required.includes(colName),
              default: colDef.default !== undefined ? String(colDef.default) : undefined
            });
          }
        }

        tables.push({
          name: tableName,
          methods: supportedMethods,
          description: (def && def.description) || '',
          columns
        });
      }
    }

    // Sort alphabetically
    tables.sort((a, b) => a.name.localeCompare(b.name));
    rpcFunctions.sort((a, b) => a.name.localeCompare(b.name));

    // Generate markdown report
    const mdLines = [];
    mdLines.push('# مرجع OpenAPI المستخرج لقاعدة بيانات Supabase (Data API)');
    mdLines.push('');
    mdLines.push(`- **نقطة الوصول (Host):** \`${parsedHost}\``);
    mdLines.push(`- **بروتوكول الواجهة:** PostgREST / OpenAPI Specification`);
    mdLines.push(`- **تاريخ الاستخراج:** ${new Date().toISOString()}`);
    mdLines.push(`- **طريقة الاستخراج:** طلب خادم خلفي آمن مع ترويسة المصادقة المعتمدة (بدون تمرير المفتاح في URL أو المتصفح).`);
    mdLines.push(`- **إجمالي الجداول والـ Views المكتشفة:** ${tables.length}`);
    mdLines.push(`- **إجمالي دوال RPC المكتشفة:** ${rpcFunctions.length}`);
    mdLines.push('');
    mdLines.push('---');
    mdLines.push('');
    mdLines.push('## 1. ما تم كشفه عبر مواصفة OpenAPI');
    mdLines.push('تسمح مواصفة PostgREST OpenAPI الرسمية بالتعرف على كافة الموارد العامة المكشوفة للعميل:');
    mdLines.push('1. الجداول والقوائم (Tables & Views) المتاحة للاستعلام والإدراج والتحديث.');
    mdLines.push('2. أسماء الأعمدة الدقيقة، أنواع البيانات (Data Types)، وحالة الإلزام (Required / Nullable).');
    mdLines.push('3. دوال الـ RPC المعلنة، أسماء معاملاتها (Parameters)، وأنواع القيم المعادة.');
    mdLines.push('');
    mdLines.push('---');
    mdLines.push('');
    mdLines.push('## 2. ما لا تستطيع مواصفة OpenAPI كشفه بطبيعتها (حدود المواصفة)');
    mdLines.push('تقتصر مواصفة OpenAPI على واجهة العقد (Contract/Schema Interface) ولا يمكنها كشف التفاصيل الداخلية التالية:');
    mdLines.push('- **كود الدوال الداخلي (Function Body / PLpgSQL Code):** لا يظهر منطق التحقق الداخلي المكتوب داخل PostgreSQL.');
    mdLines.push('- **مشغلات الأحداث (Triggers):** لا تكشف OpenAPI الـ Triggers المنفذة تلقائياً في الخلفية داخل قاعدة البيانات.');
    mdLines.push('- **سياسات أمان الصفوف الكاملة (RLS Policies):** لا تكشف تعابير `USING` أو `WITH CHECK` المكتوبة في SQL، بل تكتفي بتحديد ما إذا كان المسار متاحاً للـ Role الحالي.');
    mdLines.push('- **فهارس الأداء المخصصة (Custom Indexes):** لا تظهر الفهارس غير الفريدة (مثل B-tree indexes) داخل OpenAPI.');
    mdLines.push('*(ملاحظة: لمعرفة هذه العناصر الخمسة دون تخمين، يتطلب الأمر فحص فهارس نظام PostgreSQL `pg_catalog` في مرحلة لاحقة عبر جلسة قراءة فقط).*');
    mdLines.push('');
    mdLines.push('---');
    mdLines.push('');
    mdLines.push('## 3. قائمة دوال RPC المكتشفة ومعاملاتها');
    mdLines.push('');
    if (rpcFunctions.length === 0) {
      mdLines.push('*لم يتم العثور على دوال RPC مكشوفة للصلاحية المستخدمة.*');
    } else {
      mdLines.push('| اسم الدالة (RPC) | طريقة HTTP | المعاملات (Parameters) | نوع القيمة المعادة |');
      mdLines.push('| :--- | :--- | :--- | :--- |');
      for (const fn of rpcFunctions) {
        const paramStr = fn.parameters.length > 0
          ? fn.parameters.map(p => `\`${p.name}\`: ${p.type}${p.required ? ' *' : ''}`).join(', ')
          : '—';
        mdLines.push(`| **\`${fn.name}\`** | \`${fn.httpMethod}\` | ${paramStr} | \`${fn.returnType}\` |`);
      }
    }
    mdLines.push('');
    mdLines.push('---');
    mdLines.push('');
    mdLines.push('## 4. قائمة الجداول والأعمدة المكتشفة');
    mdLines.push('');
    for (const tbl of tables) {
      mdLines.push(`### جدول: \`${tbl.name}\``);
      if (tbl.description) {
        mdLines.push(`> ${tbl.description}`);
      }
      mdLines.push(`- **العمليات المدعومة:** ${tbl.methods.map(m => `\`${m}\``).join(', ')}`);
      mdLines.push('');
      if (tbl.columns.length > 0) {
        mdLines.push('| اسم العمود | النوع (Type) | التنسيق (Format) | إلزامي (Required) | القيمة الافتراضية |');
        mdLines.push('| :--- | :--- | :--- | :--- | :--- |');
        for (const col of tbl.columns) {
          mdLines.push(`| **\`${col.name}\`** | \`${col.type}\` | ${col.format ? `\`${col.format}\`` : '—'} | ${col.required ? 'نعم (مطلوب)' : 'اختياري'} | ${col.default !== undefined ? `\`${col.default}\`` : '—'} |`);
        }
      } else {
        mdLines.push('*لا توجد تفاصيل أعمدة معلنة في هذا المورد.*');
      }
      mdLines.push('');
    }

    const docsDir = path.resolve('docs');
    if (!fs.existsSync(docsDir)) {
      fs.mkdirSync(docsDir, { recursive: true });
    }

    const targetFile = path.join(docsDir, 'SUPABASE_OPENAPI_REFERENCE.md');
    fs.writeFileSync(targetFile, mdLines.join('\n'), 'utf8');

    console.log(JSON.stringify({
      success: true,
      host: parsedHost,
      totalTables: tables.length,
      totalRpc: rpcFunctions.length,
      savedPath: 'docs/SUPABASE_OPENAPI_REFERENCE.md',
      tablesSummary: tables.map(t => ({ name: t.name, columnCount: t.columns.length })),
      rpcSummary: rpcFunctions.map(r => ({ name: r.name, paramCount: r.parameters.length }))
    }));
  } catch (err) {
    console.error(JSON.stringify({
      success: false,
      host: parsedHost,
      error: (err && err.message) ? err.message : String(err)
    }));
    process.exit(1);
  }
}

run();
